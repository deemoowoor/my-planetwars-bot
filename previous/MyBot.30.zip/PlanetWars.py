#!/usr/bin/env python
#

from math import modf, floor, ceil, sqrt
from sys import stdout
import sys
from debug import debug

class Fleet:
    def __init__(self, owner, num_ships, source_planet, destination_planet, \
     total_trip_length, turns_remaining):
        self._owner = owner
        self._num_ships = num_ships
        self._source_planet = source_planet
        self._destination_planet = destination_planet
        self._total_trip_length = total_trip_length
        self._turns_remaining = turns_remaining

    def Owner(self):
        return self._owner

    def NumShips(self):
        return self._num_ships

    def Source(self):
        return self._source_planet

    def Destination(self):
        return self._destination_planet

    def TotalTripLength(self):
        return self._total_trip_length

    def TurnsRemaining(self):
        return self._turns_remaining

    def __repr__(self):
        return "F(%d) #%d %s >> %s ETA %d" % (self._owner, self._num_ships, self._source_planet, self._destination_planet, self._turns_remaining)
        

def mapFleetsToTurns(fleets):
    if len(fleets) == 0:
        return []
    fleets.sort(cmp, key=lambda f: f.TurnsRemaining())
    first = fleets[0]
    turnDict = {first.TurnsRemaining() : [first.NumShips() if first.Owner() == 1 else 0, first.NumShips() if first.Owner() != 1 else 0]}
    #debug("mapFleetsToTurnsStart:", turnDict, fleets)
    curturn = 0

    for f in fleets[1:]:
        turn = f.TurnsRemaining()
        if curturn == 0:
            curturn = turn
        #debug("mapFleetsToTurnsStart: @", turn, curturn, turnDict)
        if curturn != turn:
            curturn = turn
            
        if turn not in turnDict:
            turnDict[turn] = [0,0]
            
        if f.Owner() == 1:
            turnDict[turn][0] += f.NumShips()
        else:
            turnDict[turn][1] += f.NumShips()
    
    #debug("MapFleetsToTurns", turnDict)
    turnList = map(lambda item: (item[0], item[1][0], item[1][1]), turnDict.items())
    turnList.sort(cmp, key=lambda f: f[0])
    return turnList

class Planet:
    def __init__(self, pw, planet_id, owner, num_ships, growth_rate, x, y):
        self._pw = pw
        self._planet_id = planet_id
        self._owner = owner
        self._num_ships = num_ships
        self._growth_rate = growth_rate
        self._x = x
        self._y = y
        self._reserve = 0
        
    def __repr__(self):
        return "P%d(%d) ^%d(%d) +%d" % (self._planet_id, self._owner, self._num_ships, self._reserve, self._growth_rate)
        
    def ID(self):
        return self._planet_id

    def Owner(self, new_owner=None):
        if new_owner == None:
            return self._owner
        self._owner = new_owner

    def NumShipsDispatch(self):
        return max(self._num_ships - self._reserve, 0)
        
    def NumShips(self, new_num_ships=None):
        if new_num_ships == None:
            return self._num_ships
        self._num_ships = new_num_ships

    def GrowthRate(self):
        return self._growth_rate

    def X(self):
        return self._x

    def Y(self):
        return self._y

    def AddShips(self, amount):
        self._num_ships += amount

    def RemoveShips(self, amount):
        self._num_ships -= amount

    def ReserveShips(self, amount):
        self._reserve += amount
        
    def DistanceTo(self, destination):
        dx = self._x - destination.X()
        dy = self._y - destination.Y()
        dist = sqrt(dx * dx + dy * dy)
        # TODO: is this distance calc valid?
        if modf(dist)[1] >= 0.5:
            return int(ceil(dist))
        else:
            return int(floor(dist))
    
    def ClosestEnemy(self, exclude=[]):
        if getattr(self, '_eplanets', None) == None:
            self._eplanets = self._pw.EnemyPlanets()
        if len(self._eplanets) == 0:
                self._closest_enemy = self
        if getattr(self, '_closest_enemy', None) == None:
            self._closest_enemy = min(self._eplanets, key=lambda p: \
                                      self.DistanceTo(p) if p.ID() != self.ID() and p not in exclude else sys.maxint)
        return self._closest_enemy
        
    def ClosestFriendly(self, exclude=[]):
        if getattr(self, '_mplanets', None) == None:
            self._mplanets = self._pw.MyPlanets()

        if len(self._mplanets) == 0:
            self._closest_friend = self
            
        if getattr(self, '_closest_friend', None) == None:
            self._closest_friend = min(self._mplanets, key=lambda p: \
                                       self.DistanceTo(p) if p.ID() != self.ID() and p not in exclude else sys.maxint)
        return self._closest_friend
    
    def IncomingFleets(self):
        if getattr(self, '_incomingfleets', None) == None:
            self._incomingfleets = filter(lambda f: f.Destination() == self.ID(), self._pw.Fleets())
            self._incomingfleets.sort(cmp, key=lambda f: f.TurnsRemaining())
        return self._incomingfleets
    
    def CombineIncomingFleets(self, ff=[], turnlimit=sys.maxint, haveDebug=False):
        """ Estimate planet defensive strength, i.e. how much it can hold up by itself """
        if not ff and getattr(self, '_incomingfleetscombined', None) != None:
            if turnlimit not in self._incomingfleetscombined:
                closest = max(filter(lambda t: t < turnlimit, self._incomingfleetscombined.keys()))
                closeststr, cowner = self._incomingfleetscombined[closest]
                gr = self._growth_rate if cowner != 0 else 0
                strength = closeststr + gr * (turnlimit - closest)
                if haveDebug:
                    debug('turnlimit', turnlimit,'not in combined fleets for ', self.ID(), 'adding:', strength, cowner)
                self._incomingfleetscombined[turnlimit] = (strength, cowner)
            if haveDebug:
                debug(self.ID(), '@', turnlimit, self._incomingfleetscombined[turnlimit])
            return self._incomingfleetscombined[turnlimit]
            
        powner = self._owner
        gr = self._growth_rate if powner != 0 else 0
        pstrength = 0
        pstrength += self._num_ships
        
        if not ff and not getattr(self, '_incomingfleetscombined', None):
            self._incomingfleetscombined = { 0 : (pstrength, powner) }
        
        fleets = self.IncomingFleets() + ff
        
        if haveDebug:
            debug(fleets)
        
        if not ff:
            self._incomingfleetscombined[sys.maxint] = (pstrength, powner)
        
        turnList = mapFleetsToTurns(fleets)
        curturn = turnList[0][0] if len(turnList) > 0 else 0
        
        if haveDebug:
            debug("Combining fleets for:", self.ID(), '@', turnlimit, turnList)
            
        for turn,mforce,eforce in turnList:
            turns_interval = (turn - curturn)
            gr = self._growth_rate if powner != 0 else 0
            
            if ff and turn > turnlimit:
                return (pstrength, powner)
            
            if not ff:
                for t in xrange(curturn, turn):
                    if haveDebug:
                        debug("adding: @", t, pstrength + (t - curturn) * gr)
                    self._incomingfleetscombined[t] = (pstrength + (t-curturn) * gr, powner)
                    
            curturn = turn
            if haveDebug:
                debug("   >>>", self.ID(), '@', turn, '<>', turns_interval, 'owner:', powner, \
                    '>< p', pstrength, 'm', mforce, 'e', eforce, 'gr', turns_interval * gr)
            
            pstrength += turns_interval * gr
            
            if powner == 0:
                # neutral planets always have their ships decimated with no growth
                # If two enemies meet on a neutral planet, the two strongest will fight with each other
                sides = [[0, pstrength], [1, mforce], [2, eforce]]
                while sides:
                    smallest = min(sides, key=lambda x: x[1])
                    sides_max = []
                    for s in sides:
                        if s[0] == smallest[0]:
                            continue
                        s[1] -= smallest[1]
                        sides_max.append(s)
                    sides = sides_max
                if smallest[1] > 0:
                    powner = smallest[0]
                pstrength = smallest[1]
            elif powner == 1:
                pstrength += mforce
                pstrength -= eforce
                if pstrength < 0:
                    powner = 2
                    pstrength = -pstrength
            elif powner == 2:
                pstrength -= mforce
                pstrength += eforce
                if pstrength < 0:
                    powner = 1
                    pstrength = -pstrength
            #debug("   >", self.ID(), '@', turn, '<>', turns_interval, 'owner:', powner, '>< p', \
            #pstrength, 'm', mforce, 'e', eforce, 'gr', turns_interval * gr)
        if ff:
            return (pstrength, powner)
        
        if not ff:
            self._incomingfleetscombined[curturn] = (pstrength, powner)
        
        gr = self._growth_rate if powner != 0 else 0
        
        if turnlimit < sys.maxint:
            for t in xrange(curturn, turnlimit+1):
                if haveDebug:
                    debug("adding: @", t, pstrength + (t - curturn) * gr, gr, powner, curturn)
                self._incomingfleetscombined[t] = (pstrength + (t-curturn) * gr, powner)
        
        if turnlimit == sys.maxint or sys.maxint not in self._incomingfleetscombined:
            self._incomingfleetscombined[sys.maxint] = (pstrength, powner)
            
        if turnlimit not in self._incomingfleetscombined:
            closest = max(filter(lambda t: t < turnlimit, self._incomingfleetscombined.keys()))
            closeststr, owner = self._incomingfleetscombined[closest]
            gr = self._growth_rate if owner != 0 else 0
            strength = closeststr + gr * (turnlimit - closest)
            self._incomingfleetscombined[turnlimit] = (strength, owner)
        
        if haveDebug:
            debug("   final for:", self.ID(), pstrength, powner, "@", turnlimit, ":", self._incomingfleetscombined[turnlimit]);
            
        return self._incomingfleetscombined[turnlimit]
    
    def SetRescued(self, rescued):
        self._rescued = rescued
    
    def IsRescued(self):
        if getattr(self, '_rescued', None) == None:
            self._rescued = False
        return self._rescued
    
    def GetLocalGroup(self, threatDist):
        if getattr(self, '_localGroup', None) == None:
            self._localGroup = dict()
        if threatDist not in self._localGroup:
            self._localGroup[threatDist] = filter(lambda p: 
                self.DistanceTo(p) < threatDist and p.ID() != self.ID(), self._pw.Planets())
        return self._localGroup[threatDist]
            
    def GetLocalGroupDefenceStrength(self, threatDist, ff=[], haveDebug=False):
        if getattr(self, '_localGroupDefenceStrength', None) == None:
            self._localGroupDefenceStrength = dict()
        
        if not ff and threatDist in self._localGroupDefenceStrength:
            return self._localGroupDefenceStrength[threatDist]
        
        pgds = 0
        localGroup = self.GetLocalGroup(threatDist)
        
        if haveDebug:
            debug("     pgds for", self.ID(), "localGroup:", localGroup)
            
        powner = self._owner
        for p in localGroup:
            safeDistance = max(0, threatDist - p.DistanceTo(self))
            pds, gpowner = p.CombineIncomingFleets(ff=ff, turnlimit=safeDistance)
            if gpowner != powner or gpowner == 0:
                continue
            pgds += pds
            
        pgds = (-pgds if powner != 1 else pgds)
        
        if ff:
            return pgds
    
        if haveDebug:
            debug("     pgds for", self.ID(), "@", threatDist, ":", pgds)
        self._localGroupDefenceStrength[threatDist] = pgds
        return self._localGroupDefenceStrength[threatDist]
        
    def GetLocalThreatStrength(self, threatDist):
        if getattr(self, '_localGroupOffenceStrength', None) == None:
            self._localGroupOffenceStrength = dict()
        
        if threatDist in self._localGroupOffenceStrength:
            return self._localGroupOffenceStrength[threatDist]
        localEnemyGroup = filter(lambda p: p.Owner() != self._owner, self.GetLocalGroup(threatDist))
        threatstrength = 0
        for p in localEnemyGroup:
            threatstrength += min(p.GetOffensiveThreat(self), 0) if self._owner == 2 else max(p.GetOffensiveThreat(self), 0)
        
        self._localGroupOffenceStrength[threatDist] = threatstrength
        return self._localGroupOffenceStrength[threatDist]
        
    def GetOffensiveThreat(self, dp, turnlimit=sys.maxint, haveDebug=False):
        """ Calculate the potential of a source planet (self) to build a successful 
        'all-out' attack on another, dp. Result number represents exactly how many
        ships will be left after the attack.
        """
        distance = self.DistanceTo(dp)
        dgrowth = dp.GrowthRate()
        
        limit = min(distance, turnlimit) # set upper limit to double of the distance
        maxstrength, maxstrengthowner = self.CombineIncomingFleets(turnlimit=0)
        if maxstrengthowner == 0:
            maxstrength = 0
        maxstrengthturn = 0
        dgrowth = dp.GrowthRate() if maxstrengthowner != 0 else 0
        maxstrength -= dgrowth * distance
        turnsOfInterest = map(lambda f: f.TurnsRemaining(), self.IncomingFleets())
        turnsOfInterest.sort(cmp)
        if len(turnsOfInterest):
            turnsOfInterest += xrange(turnsOfInterest[-1], limit+1)
        elif maxstrengthowner != 0:
            turnsOfInterest += xrange(0, limit+1)
        
        for turn in turnsOfInterest:
            spstrength, spowner = self.CombineIncomingFleets(turnlimit=turn)
            dpstrength, dpowner = dp.CombineIncomingFleets(turnlimit=turn)
            
            if spowner == 0 or spowner == dpowner:
                continue
            
            dgrowth = dp.GrowthRate() if spowner != 0 else 0
            spstrength -= dgrowth * (distance + turn)
            if spowner != dpowner and maxstrength < spstrength:
                maxstrength = spstrength
                maxstrengthturn = turn
                maxstrengthowner = spowner
        
        #if haveDebug:
        #    debug("      pOffThreat:", self.ID(), ">", dp.ID(), maxstrength, '@', maxstrengthturn, '@limit:', limit)
            
        if maxstrengthowner == 0:
            return 0
        
        maxstrength = -maxstrength if self._owner != 1 else maxstrength
        return maxstrength

    def IssueOrder(self, dp, strength):
        debug("DISPATCH ORDER:", self, ">", dp, "^", strength, "of", self.NumShipsDispatch())
        if strength < 0 or strength > self.NumShipsDispatch() or strength > self.NumShips():
            raise Exception("Invalid dispatch order!")
        self._pw.IssueOrder(self.ID(), dp.ID(), strength)
        distance = self.DistanceTo(dp)
        newfleet = Fleet(self.Owner(), strength, self.ID(), dp.ID(), distance, distance)
        dp.IncomingFleets().append(newfleet)
        self._pw.Fleets().append(newfleet)
        if self.Owner() == 1:
            self._pw.MyFleets().append(newfleet)
        else:
            self._pw.EnemyFleets().append(newfleet)
        self.RemoveShips(strength)
        dp._incomingfleetscombined = None

class PlanetWars:
    def __init__(self, gameState):
        self._planets = []
        self._fleets = []
        self.ParseGameState(gameState)

    def NumPlanets(self):
        return len(self._planets)

    def GetPlanet(self, planet_id):
        return self._planets[planet_id]

    def NumFleets(self):
        return len(self._fleets)

    def GetFleet(self, fleet_id):
        return self._fleets[fleet_id]

    def Planets(self, owner=None):
        if owner == 0:
            return self.NeutralPlanets()
        if owner == 1:
            return self.MyPlanets()
        if owner == 2:
            return self.EnemyPlanets()
        return self._planets
    
    def MyPlanets(self):
        if not getattr(self, '_my_planets', None):
            self._my_planets = []
            for p in self._planets:
                if p.Owner() != 1:
                    continue
                self._my_planets.append(p)
        return self._my_planets

    def NotMyPlanets(self):
        if not getattr(self, '_notmy_planets', None):
            self._notmy_planets = []
            for p in self._planets:
                if p.Owner() == 1:
                    continue
                self._notmy_planets.append(p)
        return self._notmy_planets
    
    def NeutralPlanets(self):
        if not getattr(self, '_neutral_planets', None):
            self._neutral_planets = []
            for p in self._planets:
                if p.Owner() != 0:
                    continue
                self._neutral_planets.append(p)
        return self._neutral_planets
        
    def NotNeutralPlanets(self):
        if not getattr(self, '_notneutral_planets', None):
            self._notneutral_planets = []
            for p in self._planets:
                if p.Owner() == 0:
                    continue
                self._notneutral_planets.append(p)
        return self._notneutral_planets
    
    def EnemyPlanets(self):
        if not getattr(self, '_enemy_planets', None):
            self._enemy_planets = []
            for p in self._planets:
                if p.Owner() <= 1:
                    continue
                self._enemy_planets.append(p)
        return self._enemy_planets
        
    def Fleets(self):
        return self._fleets

    def MyFleets(self):
        if not getattr(self, '_my_fleets', None):
            self._my_fleets = []
            for f in self._fleets:
                if f.Owner() != 1:
                    continue
                self._my_fleets.append(f)
        return self._my_fleets

    def EnemyFleets(self):
        if not getattr(self, '_enemy_fleets', None):
            self._enemy_fleets = []
            for f in self._fleets:
                if f.Owner() <= 1:
                    continue
                self._enemy_fleets.append(f)
        return self._enemy_fleets

    def MyProduction(self):
        return sum(map(lambda p: p.GrowthRate(), self.MyPlanets()))

    def EnemyProduction(self):
        return sum(map(lambda p: p.GrowthRate(), self.EnemyPlanets()))

    def ToString(self):
        s = ''
        for p in self._planets:
            s += "P %f %f %d %d %d\n" % \
             (p.X(), p.Y(), p.Owner(), p.NumShips(), p.GrowthRate())
        for f in self._fleets:
            s += "F %d %d %d %d %d %d\n" % \
             (f.Owner(), f.NumShips(), f.Source(), f.Destination(), \
                f.TotalTripLength(), f.TurnsRemaining())
        return s

    def Distance(self, source_planet, destination_planet):
        source = self._planets[source_planet]
        destination = self._planets[destination_planet]
        dx = source.X() - destination.X()
        dy = source.Y() - destination.Y()
        dist = sqrt(dx * dx + dy * dy)
        # TODO: is this distance calc valid?
        if modf(dist)[1] >= 0.5:
            return int(ceil(dist))
        else:
            return int(floor(dist))

    def IssueOrder(self, source_planet, destination_planet, num_ships):
        stdout.write("%s %s %d\n" % \
         (source_planet, destination_planet, num_ships))
        stdout.flush()

    def IsAlive(self, player_id):
        for p in self._planets:
            if p.Owner() == player_id:
                return True
        for f in self._fleets:
            if f.Owner() == player_id:
                return True
        return False

    def ParseGameState(self, s):
        self._planets = []
        self._fleets = []
        lines = s.split("\n")
        planet_id = 0

        for line in lines:
            line = line.split("#")[0] # remove comments
            tokens = line.split(" ")
            if len(tokens) == 1:
                continue
            if tokens[0] == "P":
                if len(tokens) != 6:
                    return 0
                p = Planet(self, planet_id, # The ID of this planet
                             int(tokens[3]), # Owner
                             int(tokens[4]), # Num ships
                             int(tokens[5]), # Growth rate
                             float(tokens[1]), # X
                             float(tokens[2])) # Y
                planet_id += 1
                self._planets.append(p)
            elif tokens[0] == "F":
                if len(tokens) != 7:
                    return 0
                f = Fleet(int(tokens[1]), # Owner
                            int(tokens[2]), # Num ships
                            int(tokens[3]), # Source
                            int(tokens[4]), # Destination
                            int(tokens[5]), # Total trip length
                            int(tokens[6])) # Turns remaining
                self._fleets.append(f)
            else:
                return 0
        return 1

    def FinishTurn(self):
        stdout.write("go\n")
        stdout.flush()
