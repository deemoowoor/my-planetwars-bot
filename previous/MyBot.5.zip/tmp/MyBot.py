#!/usr/bin/env python
#

"""
The DoTurn function is where your code goes. The PlanetWars object contains
the state of the game, including information about all planets and fleets
that currently exist. Inside this function, you issue orders using the
pw.IssueOrder() function. For example, to send 10 ships from planet 3 to
planet 8, you would say pw.IssueOrder(3, 8, 10).

 There is already a basic strategy in place here. You can use it as a
starting point, or you can throw it out entirely and replace it with your
own. Check out the tutorials and articles on the contest website at
http://www.ai-contest.com/resources.
"""

from PlanetWars import PlanetWars, Fleet
import sys
#debuglog = file('debuglog.txt','w+')
gameturn = 0

def debug(*args):
    #global debuglog
    s = ' '.join([str(a) for a in args]) + '\n'
    #sys.stderr.write(s)
    #sys.stderr.flush()
    #debuglog.write(s)
    #debuglog.flush()
    pass
        
def DoTurn(pw):
    global gameturn
    gameturn += 1
    debug("\n\n##################################################");
    debug("Turn", gameturn)
    debug("My planets:")
    mplanets = pw.MyPlanets()
    eplanets = pw.EnemyPlanets()
    for mp in mplanets:
        closest_ep = mp
        if len(eplanets) > 0:
            closest_ep = min(eplanets, key=lambda p: p.DistanceTo(mp))
        debug(mp, " +", mp.GrowthRate(), " ^", mp.NumShips(), 'Closest ep:', closest_ep.ID(), '@', closest_ep.DistanceTo(mp), ' ^', closest_ep.NumShips())

    mfleets = pw.MyFleets()    
    debug("My fleets:", len(mfleets))
    mfleets.sort(lambda f,s: cmp(f.SourcePlanet(), s.SourcePlanet()))
    for mf in mfleets:
        dest_ships = pw.GetPlanet(mf.DestinationPlanet()).NumShips()
        debug(">> ", mf.SourcePlanet(), '>>', mf.DestinationPlanet(), " ^", mf.NumShips(), 'vs', dest_ships, " <>", mf.TurnsRemaining())
    
    debug("Enemy planets:")
    for ep in eplanets:
        closest_mp = ep
        if len(mplanets) > 0:
            closest_mp = min(mplanets, key=lambda p: p.DistanceTo(mp))
        debug(ep, " +", ep.GrowthRate(), " ^", ep.NumShips(), 'Closest mp:', closest_mp.ID(), '@', closest_mp.DistanceTo(ep), ' ^', closest_mp.NumShips())
    
    efleets = pw.EnemyFleets()
    debug("Enemy fleets:", len(efleets))
    efleets.sort(lambda f,s: cmp(f.SourcePlanet(), s.SourcePlanet()))
    for ef in efleets:
        dest_ships = pw.GetPlanet(ef.DestinationPlanet()).NumShips()
        debug("<< ", ef.SourcePlanet(), '>>', ef.DestinationPlanet(),  ' ^', ef.NumShips(), 'vs', dest_ships, " <>", ef.TurnsRemaining())
    
    debug("REINFORCEMENTS AND DEFENCE #######################");
    defendOwnPlanets(pw)
    debug("RECAPTURE-----------------------------------------");
    recapturePlanets(pw)
    debug("ATTACK--------------------------------------------");
    attackEnemy(pw)
    debug("REGROUP-------------------------------------------");
    regroupOwn(pw)

def mapFleetsToTurns(fleets):
    fleets.sort(lambda f,s: cmp(f.TurnsRemaining(), s.TurnsRemaining()))
    curturn = min([ef.TurnsRemaining() for ef in fleets])
    curturn_fleets = []
    turn_list = [(curturn, curturn_fleets)]
    
    for ef in fleets:
        turn = ef.TurnsRemaining()
        if curturn != turn:
            curturn = turn
            curturn_fleets = []
            turn_list.append((curturn, curturn_fleets))
        curturn_fleets.append(ef)
    
    turn_list.sort(lambda f,s: cmp(f[0], s[0]))
    return turn_list

def mapFleetsToDestinationPlanets(fleets):
    fleets.sort(lambda f,s: cmp(f.DestinationPlanet(), s.DestinationPlanet()))
    curdp = min([ef.DestinationPlanet() for ef in fleets])
    
    curdp_fleets = []
    dp_list = [(curdp, curdp_fleets)]
    
    for ef in fleets:
        dp = ef.DestinationPlanet()
        if curdp != dp:
            curdp = dp
            curdp_fleets = []
            dp_list.append((curdp, curdp_fleets))
        curdp_fleets.append(ef)
    
    dp_list.sort(lambda f,s: cmp(f[0], s[0]))
    return dp_list

def defendOwnPlanets(pw):
    """ Manage defence of own planets:  """
    fleets = pw.Fleets()
    splanets = pw.MyPlanets()
    dplanets = pw.MyPlanets()
    eplanets = pw.EnemyPlanets()
    
    splanets.sort(lambda f,s: -cmp(f.NumShips(), s.NumShips));
    mplanetid = [sp.ID() for sp in splanets]
    
    efleets = filter(lambda ef: ef.DestinationPlanet() in mplanetid, pw.EnemyFleets())
    
    planetRatingL = lambda f: planetRating(f, eplanets, splanets, fleets)
    dplanets.sort(lambda f,s: -cmp(planetRatingL(f), planetRatingL(s)))
    
    if len(efleets) == 0:
        return
    
    # map fleets to planets:
    dpfleets = mapFleetsToDestinationPlanets(efleets)
    
    for dpid, defleets in dpfleets:
        sent = 0
        
        dp = pw.GetPlanet(dpid)
        
        # STEP 0: see, if the planet needs rescue
        uncertainty_limit = min([dp.DistanceTo(ep) for ep in eplanets]) \
            if len(eplanets) > 0 else sys.maxint
        
        dpds,dpowner = estimatedPlanetDefenceStrength(dp, fleets, uncertainty_limit=uncertainty_limit)
        
        debug("DEFENDING: >>|", dp.ID(), 'visibility:', uncertainty_limit, 'dpds:', dpds, 'owner:', dpowner)
        
        if dpowner == 1 or len(defleets) == 0:
            continue
        
        # STEP 1: map enemy fleets to turns in which they will come to the dp
        # map fleets to destination maps, filtering out only those coming to ours
        defleets_turns = mapFleetsToTurns(defleets)
        
        # STEP 2: get amount of needed ships in each turn and concoct a rescue plan
        fanthom_fleets = []
        for turn, tdefleets in defleets_turns:
            dpds_turn,dpowner_turn = estimatedPlanetDefenceStrength(dp, fleets, 
                fanthom_fleets = fanthom_fleets, 
                uncertainty_limit=min(uncertainty_limit, turn))
                
            debug("  @turn:", turn, "^", dpds_turn, 'own:', dpowner_turn)
            
            if dpowner_turn != 1:
                ff = Fleet(dp.Owner(), dpds_turn, 1, dpid, 0, turn - 1)
                debug("     Adding fanthom:", dpds_turn, '@', turn - 1)
                fanthom_fleets.append(ff)
        
        rescuePlan = [(ff.TurnsRemaining(), ff.NumShips()) for ff in fanthom_fleets]
        debug("  Rescue plan:", rescuePlan)
        
        # STEP 3: find resources for the rescue plan
        rescuePlanets = []
        safeLimits = dict()
        
        splanetsnodp = filter(lambda sp: sp.ID() != dp.ID(), splanets)
        
        for sp in splanetsnodp:
            safeLimits[sp.ID()] = safeDispatchLimit(sp, dp, eplanets, fleets)
            #debug('    Added safeDispatchLimit to', sp.ID(), ':', safeLimits[sp.ID()])
            
        for turn, nships in rescuePlan:
            nships_left = nships
            curRP = []
            for sp in splanetsnodp:
                if turn < sp.DistanceTo(dp): # too close to destination, can't save
                    continue
                futureGrowth = sp.GrowthRate() * min(turn - sp.DistanceTo(dp), uncertainty_limit)
                safeLimit = safeLimits[sp.ID()] + futureGrowth
                if safeLimit <= 0:
                    continue
                dispatch = min(nships_left, safeLimit)
                nships_left -= dispatch
                debug('  ', sp.ID(), 'is saving', dp.ID(), 'added:', dispatch, 'safelimit:', safeLimit, 'left:', nships_left, \
                    'need:', nships, 'slPure:', safeLimits[sp.ID()], 'futureGrowth', futureGrowth)
                curRP.append((sp, dispatch))
                if nships_left <= 0:
                    break
                    
            rescuePlanets.append((turn, nships, curRP))
            if nships_left > 0:
                debug("  WARNING: CAN'T FULFILL THE RESCUE PLAN @", turn, " Left:", nships_left, 'needed:', nships, 'on turn', turn)
            #    debug([(turn, [(sp, sl, sp.DistanceTo(dp)) for sp, sl in data]) for turn, data in rescuePlanets])
            #    rescuePlanets = []
            #    break
        
        # STEP 4: execute the plan
        for turn, nships, curRP in rescuePlanets:
            nships_left = nships
            for sp, dispatch in curRP:
                if nships_left < 0:
                    break
                    
                fs = min(dispatch, sp.NumShips() - 1)
                nships_left -= fs
                distance = sp.DistanceTo(dp)
                if distance == turn and fs > 0:
                    debug(">>>>>>>>> SAVING:", sp, '>', dp, '!', dpds, '^', safeLimit, sp.NumShips(), 'sending:', fs)
                    pw.IssueOrder(sp.ID(), dp.ID(), fs)
                    sp.RemoveShips(fs)
                elif distance < turn and fs > 0:
                    debug("Reserving for future rescue", sp, '>', dp, " @", distance, 'eta', turn-distance, ' fleet:', fs, ' dpds', dpds)
                    sp.RemoveShips(fs)


def recapturePlanets(pw):
    """ Opportunistic weak enemy recapture """
    fleets = pw.Fleets()
    splanets = pw.MyPlanets()
    dplanets = pw.NotMyPlanets()
    eplanets = pw.EnemyPlanets()
    
    splanets.sort(lambda f,s: -cmp(f.NumShips(), s.NumShips));
    mplanetid = [sp.ID() for sp in splanets]
    
    efleets = filter(lambda ef: ef.DestinationPlanet() in mplanetid, pw.EnemyFleets())
    
    planetRatingL = lambda f: planetRating(f, eplanets, splanets, fleets)
    dplanets.sort(lambda f,s: -cmp(planetRatingL(f), planetRatingL(s)))
    
    if len(efleets) == 0:
        return
    
    # map fleets to planets:
    dpfleets = mapFleetsToDestinationPlanets(efleets)
    
    for dpid, defleets in dpfleets:
        sent = 0
        
        dp = pw.GetPlanet(dpid)
        
        # STEP 0: see, if the planet needs rescue
        uncertainty_limit = min([dp.DistanceTo(ep) for ep in eplanets]) \
            if len(eplanets) > 0 else sys.maxint
        
        dpds,dpowner = estimatedPlanetDefenceStrength(dp, fleets, uncertainty_limit=uncertainty_limit)
        
        debug("RECAPTURE OPPORTUNITY FOR: >>", dp.ID(), 'visibility:', uncertainty_limit, 'dpds:', dpds, 'owner:', dpowner)
        
        if dpowner == 1 or len(defleets) == 0:
            continue
        
        # STEP 1: map enemy fleets to turns in which they will come to the dp
        # map fleets to destination maps, filtering out only those coming to ours
        defleets_turns = mapFleetsToTurns(defleets)
        
        # STEP 2: get amount of needed ships in each turn and concoct a rescue plan
        fanthom_fleets = []
        for turn, tdefleets in defleets_turns:
        
            dpds_turn,dpowner_turn = estimatedPlanetDefenceStrength(dp, fleets, 
                fanthom_fleets = fanthom_fleets, 
                uncertainty_limit=min(uncertainty_limit, turn))
                
            debug("  @turn:", turn, "^", dpds_turn, 'own:', dpowner_turn)
            
            if dpowner_turn != 1:
                ff = Fleet(dp.Owner(), dpds_turn, 1, dpid, 0, turn - 1)
                debug("     Adding fanthom:", dpds_turn, '@', turn - 1)
                fanthom_fleets.append(ff)
        
        rescuePlan = [(ff.TurnsRemaining(), ff.NumShips()) for ff in fanthom_fleets]
        debug("  Rescue plan:", rescuePlan)
        
        # STEP 3: find resources for the rescue plan
        rescuePlanets = []
        safeLimits = dict()
        
        splanetsnodp = filter(lambda sp: sp.ID() != dp.ID(), splanets)
        
        for sp in splanetsnodp:
            safeLimits[sp.ID()] = safeDispatchLimit(sp, dp, eplanets, fleets)
            #debug('    Added safeDispatchLimit to', sp.ID(), ':', safeLimits[sp.ID()])
            
        for turn, nships in rescuePlan:
            nships_left = nships
            curRP = []
            for sp in splanetsnodp:
                if turn < sp.DistanceTo(dp): # too close to destination, can't save
                    continue
                futureGrowth = sp.GrowthRate() * min(turn - sp.DistanceTo(dp), uncertainty_limit)
                safeLimit = safeLimits[sp.ID()] + futureGrowth
                if safeLimit <= 0:
                    continue
                dispatch = min(nships_left, safeLimit)
                nships_left -= dispatch
                debug('  ', sp.ID(), 'is recapturing', dp.ID(), 'added:', dispatch, 'safelimit:', safeLimit, 'left:', nships_left, \
                    'need:', nships, 'slPure:', safeLimits[sp.ID()], 'futureGrowth', futureGrowth)
                curRP.append((sp, dispatch))
                if nships_left <= 0:
                    break
                    
            rescuePlanets.append((turn, nships, curRP))
            if nships_left > 0:
                debug("  WARNING: CAN'T FULFILL THE RECAPTURE PLAN @", turn, " Left:", nships_left, 'needed:', nships, 'on turn', turn)
            #    debug([(turn, [(sp, sl, sp.DistanceTo(dp)) for sp, sl in data]) for turn, data in rescuePlanets])
            #    rescuePlanets = []
            #    break
        
        # STEP 4: execute the plan
        for turn, nships, curRP in rescuePlanets:
            nships_left = nships
            for sp, dispatch in curRP:
                if nships_left < 0:
                    break
                    
                fs = min(dispatch, sp.NumShips() - 1)
                nships_left -= fs
                distance = sp.DistanceTo(dp)
                if distance == turn and fs > 0:
                    debug(">>>>>>>>> RECAPTURE:", sp, '>', dp, '!', dpds, '^', safeLimit, sp.NumShips(), 'sending:', fs)
                    pw.IssueOrder(sp.ID(), dp.ID(), fs)
                    sp.RemoveShips(fs)
                elif distance < turn and fs > 0:
                    debug("Reserving for future recapture", sp, '>', dp, " @", distance, 'eta', turn-distance, ' fleet:', fs, ' dpds', dpds)
                    sp.RemoveShips(fs)
                    
 
def recaptureEnemy(pw): 
    """ OBSOLETE. Opportunistic weak enemy recapture """
    efleets = pw.EnemyFleets()
    mfleets = pw.MyFleets()
    fleets = pw.Fleets()
    mplanets = excludeDefensiveFromAttack(pw, pw.MyPlanets(), fleets)
    eplanets = pw.EnemyPlanets()
    
    dplanets = []
    
    for ef in efleets:
        dp = pw.GetPlanet(ef.DestinationPlanet())
        
        if dp in dplanets:
            continue

        dplanets.append(dp)
        mplanets.sort(lambda x, y: cmp(pw.Distance(dp.ID(), x.ID()), pw.Distance(dp.ID(), y.ID())))

        if dp.Owner() == ef.Owner():
            continue
        
        uncertainty = -1
        
        if len(eplanets) > 0:
            uncertainty = min([dp.DistanceTo(ep) for ep in eplanets])
        
        dpds,dpowner = estimatedPlanetDefenceStrength(dp, fleets, uncertainty_limit = uncertainty)
        total_sent = 0
        
        # TODO: implement cooperative recapture
        for mp in mplanets:
            if dp.ID() == mp.ID():
                continue
                
            distance = mp.DistanceTo(dp)
            
            safe_limit = safeDispatchLimit(mp, dp, eplanets, fleets)
            capture_strength = dpds + 1 + (ef.TurnsRemaining() + 1 - distance) * dp.GrowthRate()
            
            debug('Check recapture of', dp.ID(), '<<', mp.ID(), ' dpds/owner', dpds, dpowner, \
                'safe limit:', safe_limit, 'cap_str', capture_strength, ' <>', ef.TurnsRemaining(), '<=', distance)

            if dpowner != 1 and capture_strength > 0 and capture_strength < safe_limit and ef.TurnsRemaining() + 1 <= distance:
                debug("<<<<< RECAPTURING a weak planet!", mp.ID(), '>', dp.ID(), ' need:', capture_strength, ' have:', mp.NumShips())
                pw.IssueOrder(mp, dp, capture_strength)
                mp.RemoveShips(capture_strength)
                total_sent += capture_strength
            elif dpds + 1 < safe_limit and dpowner < 2:
                # Reserve available ships for recapture
                mp.RemoveShips(dpds + dp.GrowthRate() + 1)
                debug('Reserved for recapture ', dp.ID(), '>', mp.ID(), ':', dpds + dp.GrowthRate() + 1)

def regroupPlanetRating(planet, eplanets, mplanets):
    edist = 0
    if len(eplanets) > 0:
        edist = planetDistanceBlob(planet, eplanets)
    
    mdist = 0
    if len(mplanets) > 0:
        mdist = planetDistanceBlob(planet, mplanets)
        
    growth_factor = planet.GrowthRate()
    rating = int(edist - mdist) * growth_factor
    return rating

def regroupOwn(pw):
    """ find the weakest and most remote of own planets and enslave them to feed the bigger ones"""
    
    mplanets = pw.MyPlanets()
    nmplanets = pw.NotMyPlanets()
    eplanets = pw.EnemyPlanets()
    fleets = pw.Fleets()
    
    if len(eplanets) <= 0:
        return
    
    # TODO: Take enemy positions into account: regroup to where the enemy is closest and
    # has stronger planets
    mplanets_rating = [(p, regroupPlanetRating(p, mplanets, eplanets)) for p in mplanets]
    #mplanets_dist_blobs.sort(lambda x, y: cmp(x[1] , y[1]))
    
    # TODO: don't send ships, if sp is already a regrouping recipient. One way to find it out is
    # simply to select just one of the planets to receive the ships
    
    dp,dp_pdb = min(mplanets_rating, key=lambda x: x[1])
    #for dp,dp_pdb in mplanets_dist_blobs:
    for sp,mpdb in mplanets_rating:
        if sp == dp:
            continue
        
        closest_enemy = min([ep.DistanceTo(sp) for ep in eplanets])
        
        if sp.DistanceTo(dp) >= closest_enemy:
            continue
        
        dispatch = safeDispatchLimit(sp, dp, eplanets, fleets) - sp.GrowthRate() * closest_enemy
        
        if dispatch <= 0:
            continue
        
        debug(">>>> REGROUPING on best planet:", sp.ID(), '>', dp.ID(), ' ^', dispatch, 'of', sp.NumShips()-1)
        pw.IssueOrder(sp.ID(), dp.ID(), dispatch)
        sp.RemoveShips(dispatch)


def attackEnemy(pw):
    """ Attack enemy, when possible """

    mplanets = pw.MyPlanets()
    eplanets = sanitizePlanets(pw.EnemyPlanets())
    eplanets.sort(lambda x, y: -cmp(x.GrowthRate(), y.GrowthRate()))
    nplanets = sanitizePlanets(pw.NeutralPlanets())
    nplanets.sort(lambda x, y: -cmp(x.GrowthRate(), y.GrowthRate()))
    
    planets = sanitizePlanets(pw.NeutralPlanets())
    planets.sort(lambda x, y: -cmp(x.GrowthRate(), y.GrowthRate()))
    
    mfleets = pw.MyFleets()
    efleets = pw.EnemyFleets()
    fleets = pw.Fleets()
    
    mfleet_size = sum([mf.NumShips() for mf in mfleets])
    mplanets_size = sum([mp.NumShips() for mp in mplanets])
    
    eos = estimatedCharacterOffenceStrength(pw, eplanets, mplanets, efleets, mfleets)
    eds = estimatedCharacterDefenceStrength(eplanets, efleets)
    mos = estimatedCharacterOffenceStrength(pw, mplanets, eplanets, mfleets, efleets)
    mds = estimatedCharacterDefenceStrength(mplanets, mfleets)
    
    my_production = MyProduction(pw) 
    enemy_production = EnemyProduction(pw)
    
    enemy_threat = -(eos + mds)
    my_threat = (mos + eds)
    
    debug("# My total strength,    >>", mos, ' ||', mds, ' $', my_production, ' %>', my_threat, 'R:', my_threat, '>', enemy_threat)
    debug("# Enemy total strength, >>", -eos, ' ||', -eds, ' $', enemy_production, ' %>', enemy_threat)
    
    if my_production <= enemy_production:
        #TODO: be more aggressive, when production is less than opponent's, otherwise we loose anyway
        pass
    
    if my_production > enemy_production and (enemy_threat > 0 or mos <= 0): 
        debug("#### Waiting to grow bigger! Staying defensive.")
        return
    
    if my_production > enemy_production and (mos + eds) > -(mds + eos):
        debug("#### CHECKING WING ATTACK PLAN R")
        coordinatedAttack(pw, eplanets, mplanets, fleets, eds, mos)
        #return
    
    #mplanets = excludeDefensiveFromAttack(pw, mplanets, fleets)
    
    performCarefulOffence(pw, eplanets, eplanets, mplanets, mfleets, fleets)
    performCarefulOffence(pw, nplanets, eplanets, mplanets, mfleets, fleets)

def coordinatedAttack(pw, eplanets, mplanets, fleets, est_estrength, est_mstrength):
    """ In coordinated attack, all planets send their safe maximum to every enemy planet 
    to build waves of fleets that effectively overwhelm each planet """
    #debug("#### WING ATTACK PLAN R")
    
    total_sent = 0
    attack_plan = []
    eplanets_strength = [(estimatedPlanetDefenceStrength(ep, fleets), ep) for ep in eplanets]
    #filter(lambda p: p[0] >= 0, [(estimatedPlanetDefenceStrength(ep, fleets), ep) for ep in eplanets])
    eplanets_strength.sort(lambda f,s: -cmp(f[0], s[0]))
    
    for dpdata, ep in eplanets_strength:
        dpds, dpowner = dpdata
        max_ships = 0
        sp_dist = 0
        sp = None
        max_ships = 0
        
        for mp in mplanets:
            ships = safeDispatchLimit(mp, ep, eplanets, fleets)
            
            debug("PLAN R: Checking ", mp.ID(), ">>", ep.ID(), "^", ships, "vs dpds", -dpds)    
            
            if ships <= 0:
                continue
            
            max_ships += ships
            distance = mp.DistanceTo(ep)
            
            if distance > sp_dist:
                continue
            
            sp_dist = distance
            sp = mp
        
        if not sp:
            continue
        
        debug("PLAN R: Appending plan from", sp.ID(), ">>", ep.ID(), "^", max_ships, "vs dpds", -dpds)
        attack_plan.append((ep, sp, max_ships, dpds))
    
    for ep, sp, max_ships, dpds in attack_plan:
        if max_ships + dpds <= 0:
            debug("PLAN R: Not enough ships for PLAN R to planet >>", ep.ID(), ' total^', max_ships, 'vs dpds', -dpds)
            continue
            
        for mp in mplanets:
            num_ships = safeDispatchLimit(mp, ep, eplanets, fleets)
            
            if num_ships <= 0 or total_sent >= max_ships:
                continue
                
            pw.IssueOrder(mp.ID(), ep.ID(), num_ships)
            total_sent += num_ships
            mp.RemoveShips(num_ships)
            debug("WING ATTACK PLAN R", mp.ID(), '>>', ep.ID(), 'sent ^', num_ships, 'vs', -dpds, 'total', total_sent)
            
def safeDispatchLimitSimple(sp, dp, eplanets, fleets):
    """ Generalization of safeDispatchLimit's algorithm: safe dispatch limit is such that dispatching
    so many ships will not result in a successful enemy single planet attack """
    # defensive analysis: compare projected planet strength of our 
    # planets to planet offence potential of the enemy
    spds,spowner = estimatedPlanetDefenceStrength(sp, fleets, uncertainty_limit = min([sp.DistanceTo(ep) for ep in eplanets]))
    epos = max([estimatedPlanetOffencePotential(ep, sp, fleets) + ep.GrowthRate() for ep in eplanets])
    return min(spds + epos, sp.NumShips())
    
def safeDispatchLimit(sp, dp, eplanets, fleets):
    
    if len(eplanets) == 0:
        return 0
    
    distance = sp.DistanceTo(dp)
    
    closestEnemyDistanceToSP = min([sp.DistanceTo(ep) for ep in eplanets])
    spds,spowner = estimatedPlanetDefenceStrength(sp, fleets, uncertainty_limit=closestEnemyDistanceToSP)
    
    if dp.Owner() == 1:
        if spowner != 1:
            return 0
        
        allowed = min(sp.NumShips() - 1, spds)
        sp.RemoveShips(allowed)
        spds,spowner = estimatedPlanetDefenceStrength(sp, fleets, uncertainty_limit=closestEnemyDistanceToSP)
        sp.AddShips(allowed)

        if spowner != 1:
            return 0

        debug("Reinforcements:", sp.ID(), '>', dp.ID(), '(own)   spds', spds, \
            ' safeline:', spds, ' allowed final:', allowed)
 
        return allowed
    
    calcOffencePotentialVsSP = lambda ep: estimatedPlanetOffencePotential(ep, sp, fleets)
    
    # TODO: what if there are more than 1 with the same offence potential?
    ep = max(eplanets, key=calcOffencePotentialVsSP)
    epos = min(calcOffencePotentialVsSP(ep), 0)
    
    # simple case shortcut for single-planet enemy
    if dp.Owner() > 1 and len(eplanets) == 1: # if target is the enemy bot
        allowed = min(spds + epos, sp.NumShips() - 1)
        if allowed > 0:
            debug("Attack dispatch single planet: ", allowed, 'of', sp.NumShips())
            return allowed
        else:
            return 0
    
    eplanetsnodp = filter(lambda ep: ep.ID() != dp.ID(), eplanets)
    
    closestEnemyDistanceToDP = min([dp.DistanceTo(ep) for ep in eplanetsnodp])
    dpds,dpowner = estimatedPlanetDefenceStrength(dp, fleets, uncertainty_limit=closestEnemyDistanceToDP)
    
    # TODO: check if it's possible to subsequently save the source planet, 
    # if the enemy decides to attack it, that we can send more than spds + epos
    # defensive analysis: compare projected planet strength of our 
    # planet to offence potential of the enemy planet
    # we're safe and sound for spds + epos > 0
    # we're good to attack the enemy, while spds + epos + dpds > 0
    
    allowed = min(spds + epos, sp.NumShips() - 1)
    
    # TODO: check against enemy recapturing my freshly captured planets after I capture it
    ff = [Fleet(sp.Owner(), allowed, 1, dp.ID(), 0, distance)]
    dpds_after,dpowner_after = estimatedPlanetDefenceStrength(dp, fleets, 
        fanthom_fleets = ff, uncertainty_limit=closestEnemyDistanceToDP)
        
    calcOffencePotentialVsDP = lambda ep: estimatedPlanetOffencePotential(ep, dp, fleets)
    
    epdp = max(eplanets, key=calcOffencePotentialVsDP)
    eposdp = min(calcOffencePotentialVsDP(ep), 0)
    
    feasibility = getDispatchFeasibility(sp, dp, ep, closestEnemyDistanceToSP, epdp, closestEnemyDistanceToDP)
    
    if allowed >= 0:
        debug("#### --:", sp.ID(), '>', dp.ID(), ' ?', feasibility, ' spds', spds, ' epos', -epos,\
        ' safeline:', spds + epos, ' allowed final:', allowed, 'vs dpds/owner', dpds, dpowner, 'next offence', eposdp, 'vs', dpds_after,dpowner_after)
    
        #debug("#### --: epships:", max([ep.NumShips() for ep in eplanets]), ' mships:', sp.NumShips())
    #debug('       ', feasibility >= 0, spds > 0, spds + epos > 0, allowed + dpds > 0)
    
    if feasibility >= 0 and spowner == 1 and spds + epos > 0 and dpowner != 1:
        #debug("#### --: Allowing attack limit: ", allowed, 'of', sp.NumShips())
        return allowed
        
    return 0 # restrict attacks

def getDispatchFeasibility(sp, dp, closestEPToSP, closestEnemyDistanceToSP, closestEPToDP, closestEnemyDistanceToDP):
    
    # Enemy offence potential against the destination planet, immediately after I capture it.
    # Takes enemy planet's size and growth rate into account (working against me), as well as 
    # destination planet's growth rate working in my favor
    feasibility = 0

    feasibility = sp.GrowthRate() * closestEnemyDistanceToSP - closestEPToDP.GrowthRate() * sp.DistanceTo(dp)
    if dp.Owner() == 1:
        feasibility -= dp.GrowthRate() * closestEnemyDistanceToDP
    elif dp.Owner() > 1:
        feasibility += dp.GrowthRate() * closestEnemyDistanceToDP
    
    return feasibility
    
def performCarefulOffence(pw, dplanets, eplanets, mplanets, mfleets, fleets):
    #mplanets.sort(lambda x, y: -cmp(x.NumShips(), y.NumShips()))
    
    dplanets_ratings = [(dp, planetRating(dp, eplanets, mplanets, fleets)) for dp in dplanets]
    dplanets_ratings.sort(lambda f,s: -cmp(f[1], s[1]))
    
    for dp,dprating in dplanets_ratings:

        debug( "# DP: >", dp.ID(), "own:", dp.Owner(), " +", dp.GrowthRate(), " ^", dp.NumShips(), " R", dprating)
        dpds, dpowner = estimatedPlanetDefenceStrength(dp, fleets)
        
        if dpowner == 1: # already successfully attacked by me
            continue 
        
        dispatch_plan = []
        avg_dpdp = 0
        
        # closest first
        mplanets.sort(lambda f,s: cmp(f.DistanceTo(dp), s.DistanceTo(dp)))
    
        for sp in mplanets:
            attacklimit = safeDispatchLimit(sp, dp, eplanets, fleets)
            dpdp = estimatedPlanetDefencePotential(sp, dp, dpowner, dpds, fleets)
            dispatch_plan.append((attacklimit, dpdp, sp))
        
        dispatch_plan.sort(lambda f,s: cmp(f[1], s[1]))
        
        #min_dpdp = min([x[1] for x in dispatch_plan, ])
        #total_available = sum([x[0] for x in dispatch_plan])
        min_dpdp_source = None
        
        #if min_dpdp >= total_available:
        #    continue

        for limit, dpdp, sp in dispatch_plan:
            if limit < dpdp + 1:
                continue
            min_dpdp_source = (limit, dpdp, sp)
        
        if not min_dpdp_source:
            continue
        
        attacklimit, dpdp, sp = min_dpdp_source
        #debug("     Checking attack vectors... >>", dp.ID(), " avg dpdp", dpdp, 'available:', attacklimit, " +", dp.GrowthRate())    
        #total_sent = 0
        #for attacklimit, dpdp, sp in dispatch_plan:
        dispatch = min(attacklimit, dpdp + 1) # not just zero it out, but also increase to 1
        
        if dpowner != 1 and dispatch > 0:# and total_sent < dpdp + 1:
            debug(">>>>>>>> ATTACKING:", sp, ">", dp.ID(), "dpdp", dpdp, "^", sp.NumShips(), '>>', dispatch, 'vs', dp.NumShips())
            pw.IssueOrder(sp.ID(), dp.ID(), dispatch)
            #total_sent += dispatch
            sp.RemoveShips(dispatch)

def excludeDefensiveFromAttack(pw, mplanets, fleets):
    return filter(lambda mp: estimatedPlanetDefenceStrength(mp, fleets)[1] == 1, mplanets)

def planetDistanceBlob(planet, planets):
    if len(planets) <= 0:
        return sys.maxint
    return float(sum([planet.DistanceTo(p) for p in planets])) / float(len(planets))

def planetRating(planet, eplanets, mplanets, fleets):
    edist = 0
    if len(eplanets) > 0:
        edist = planetDistanceBlob(planet, eplanets)
    
    mdist = 0
    if len(mplanets) > 0:
        mdist = planetDistanceBlob(planet, mplanets)
        
    growth_factor = float(planet.GrowthRate())
    rating = int((float(edist) - float(mdist)) * growth_factor - planet.NumShips())
    #debug("####!! planetrating:", planet.ID(), '%.1f' % (rating), "e>", edist, " m>", mdist, " +", growth_factor)
    return rating
    
def estimatedCharacterDefenceStrength(planets, fleets):
    return sum([-pds if pdowner != 1 else pds for pds,pdowner in [estimatedPlanetDefenceStrength(p, fleets) for p in planets]])

def estimatedCharacterOffenceStrength(pw, splanets, dplanets, sfleets, dfleets):
    """ """
    if len(splanets) <= 0:
        return 0
    
    planetStrength = sum([
        sum([ estimatedPlanetCarefulOffencePotential(sp, dp, dfleets, 
            uncertainty_limit = sp.DistanceToClosestEnemyPlanet(dplanets)) 
            for sp in splanets ]) / float(len(dplanets))
                for dp in dplanets])
    
    return int(planetStrength)

def effectiveFleetStrength(pw, fleet):
    dp = pw.GetPlanet(fleet.DestinationPlanet())
    dpgrowth = 0
    if dp.Owner() != 0 and dp.Owner() != fleet.Owner():
        dpgrowth = fleet.TurnsRemaining() * dp.GrowthRate()
    
    return fleet.NumShips() - dpgrowth
    
def estimatedPlanetDefenceStrength(planet, fleets, fanthom_fleets = [], uncertainty_limit = 0):
    """ Estimate planet defensive strength, i.e. how much it can hold up by itself """
    gr = planet.GrowthRate()
    
    powner = planet.Owner()
    pstrength = planet.NumShips()
    
    lfleets = filter(lambda f: f.DestinationPlanet() == planet.ID(), fleets) + fanthom_fleets
    
    if uncertainty_limit > 0:
        lfleets = filter(lambda f: f.TurnsRemaining() <= uncertainty_limit, lfleets)
    
    if (len(lfleets)) == 0:
       #debug("pds for:", planet.ID(), '@', uncertainty_limit, (pstrength, powner))
       return (pstrength, powner)
    
    turn_list = mapFleetsToTurns(lfleets)
    
    curturn = 0
    #debug("pds for:", planet.ID(), '@', uncertainty_limit);
    for turn,turn_fleets in turn_list:
        
        turns_interval = (turn - curturn)
        curturn = turn
        my_force = sum([f.NumShips() if f.Owner() == 1 else 0 for f in turn_fleets])
        e_force = sum([f.NumShips() if f.Owner() > 1 else 0 for f in turn_fleets])
        #debug("   o", planet.ID(), '#', turn, '<>', turns_interval, 'owner:', powner, '>< p', pstrength, 'm', my_force, 'e', e_force, 'gr', turns_interval * gr)
        if powner == 0:
            # neutral planets always have their ships decimated with no growth
            # If two enemies meet on a neutral planet, the two strongest will fight with each other
            sides = [[0, pstrength], 
                [1, my_force], 
                [2, e_force]]

            while sides:
                smallest  = min(sides, key=lambda x: x[1])
                sides_max = []
                for s in sides:
                    if s[0] == smallest[0]:
                        continue
                    s[1] -= smallest[1]
                    sides_max.append(s)
                sides = sides_max
            
            pstrength = smallest[1]
            powner = smallest[0]
        elif powner == 1:
            pstrength += my_force
            pstrength -= e_force
            pstrength += turns_interval * gr

            if pstrength < 0:
                powner = 2
                pstrength = -pstrength
                
        elif powner == 2:
            pstrength -= my_force
            pstrength += e_force
            pstrength += turns_interval * gr

            if pstrength < 0:
                powner = 1
                pstrength = -pstrength
    
    #debug("   final:", pstrength, powner);
    return (pstrength, powner)

def estimatedPlanetDefencePotential(sp, dp, dpowner, dpds, fleets):
    """ Calculate the potential of a planet to defend against any attack. Number represents exactly, 
    how many ships must be sent to the planet to capture it. """
    if dpowner == 0: # neutral planets don't grow
        return dpds
    else:
        distance = sp.DistanceTo(dp)
        growthrate = dp.GrowthRate()
        return dpds + growthrate * distance

def estimatedPlanetOffencePotential(sp, dp, fleets, noGrowth = False):
    """ Calculate the potential of a source planet (sp) to build a successful 
    'all-out' attack on another, dp. Result number represents exactly how many
    ships will be left after the attack.
    """
    distance = sp.DistanceTo(dp)
    
    if sp.Owner() == 0 or dp.Owner() == sp.Owner():
        return 0
    
    growth = dp.GrowthRate()
    
    if dp.Owner() == 0 or noGrowth:
        growth = 0
    
    pstrength = 0
    #debug("#### planet offence potential", sp.ID(), '>', dp.ID(), ' <>', distance)
    if sp.Owner() != 1: # enemy
        pstrength = -sp.NumShips()
        pstrength += growth * distance
    elif sp.Owner() == 1: # me
        pstrength = sp.NumShips()
        pstrength -= growth * distance
    #debug("#### planet offence potential", sp.ID(), '>', dp.ID(), ' <>', distance, pstrength)
    return pstrength

def estimatedPlanetCarefulOffencePotential(sp, dp, fleets, fanthom_fleets = [], uncertainty_limit = -1, noGrowth = False):
    """ Calculate the potential of a planet to build a successful 'careful' attack on another,
    i.e. the one, which would not compromize its own defences. The number is the amount of ships
    available for an offensive dispatch """
    
    sp_off_potential = estimatedPlanetOffencePotential(sp, dp, fleets, noGrowth = noGrowth)
#    dp_off_potential = estimatedPlanetOffencePotential(sp, dp, fleets, noGrowth = True)
    #sp_def_strength, spowner = estimatedPlanetDefenceStrength(sp, fleets, fanthom_fleets = fanthom_fleets, uncertainty_limit = uncertainty_limit)

    #debug("- careful offence potential", sp.ID(), '>', dp.ID(), ' <>', sp.DistanceTo(dp), sp_def_strength, \
     #'-', sp_off_potential, '=', sp_def_strength - sp_off_potential)
     
    return sp_off_potential# - dp_off_potential
    
def sanitizePlanets(planets):
    """ Filter out wholly undesirable planets """
    rplanets = []
    for p in planets:
        if p.GrowthRate() > 0:
            rplanets.append(p)
    return rplanets

def MyProduction(pw):
    planets = pw.MyPlanets();
    production = 0
    for p in planets:
        production += p.GrowthRate()
    return production

def EnemyProduction(pw):
        planets = pw.EnemyPlanets();

        production = 0
        for p in planets:
            production += p.GrowthRate()
        return production

def main():
    map_data = ''
    while(True):
        current_line = raw_input()
        if len(current_line) >= 2 and current_line.startswith("go"):
            pw = PlanetWars(map_data)
            try:
                DoTurn(pw)
            except Exception,ex:
                #print "#### ERROR:", ex
                raise
            pw.FinishTurn()
            map_data = ''
        else:
            map_data += current_line + '\n'

if __name__ == '__main__':
    try:
        import psyco
        psyco.full()
    except ImportError:
        pass
        
    try:
        main()
    except KeyboardInterrupt:
        print 'ctrl-c, leaving ...'
        
