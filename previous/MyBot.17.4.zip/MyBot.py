#!/usr/bin/env python
#

from PlanetWars import PlanetWars, Fleet
import sys
import time
debuglog = None
gameturn = 0
maxtime = 0.0
maxtimeTurn = 0

def debug(*args):
    if '-d' in sys.argv[1:]:
        s = ' '.join([str(a) for a in args]) + '\n'
        sys.stderr.write(s)
        sys.stderr.flush()
    if '-dl' in sys.argv[1:]:
        global debuglog
        if not debuglog:
            debuglog = file('debuglog.txt','w+')
        s = ' '.join([str(a) for a in args]) + '\n'
        sys.stderr.write(s)
        sys.stderr.flush()
        debuglog.write(s)
        debuglog.flush()
    pass

def debugStatus(pw):
    if '-d' not in sys.argv[1:] and '-dl' not in sys.argv[1:]:
        return
        
    debug("\n\n##################################################");
    debug("Turn", gameturn)
    mplanets = pw.MyPlanets()
    eplanets = pw.EnemyPlanets()
    mfleets = pw.MyFleets()
    mfleets_size = sum([mf.NumShips() for mf in mfleets])
    mplanets_size = sum([mp.NumShips() for mp in mplanets])
    debug("My planets:", len(mplanets), ' Planets size:', mplanets_size, 'Total size:', mplanets_size + mfleets_size)
    for mp in mplanets:
        ep = mp.ClosestEnemy()
        debug(mp, " +", mp.GrowthRate(), " ^", mp.NumShips(), 'Closest e:', ep.ID(), '@', ep.DistanceTo(mp), ' ^', ep.NumShips())

    debug("My fleets:", len(mfleets), 'Total size:', mfleets_size)
    mfleets.sort(lambda f,s: cmp(f.Source(), s.Source()))
    for mf in mfleets:
        dest_ships = pw.GetPlanet(mf.Destination()).NumShips()
        debug(">> ", mf.Source(), '>>', mf.Destination(), " ^", mf.NumShips(), 'vs', dest_ships, " <>", mf.TurnsRemaining())
    
    efleets = pw.EnemyFleets()
    efleets_size = sum([ef.NumShips() for ef in efleets])
    
    eplanets_size = sum([ep.NumShips() for ep in eplanets])
    debug("Enemy planets:", len(eplanets), ' Planets size:', eplanets_size, 'Total size:', eplanets_size + efleets_size)
    for ep in eplanets:
        mp = ep.ClosestFriendly()
        debug(ep, " +", ep.GrowthRate(), " ^", ep.NumShips(), 'Closest mp:', mp.ID(), '@', mp.DistanceTo(ep), ' ^', mp.NumShips())
    
    debug("Enemy fleets:", len(efleets), 'Total size:', efleets_size)
    efleets.sort(lambda f,s: cmp(f.Source(), s.Source()))
    for ef in efleets:
        dest_ships = pw.GetPlanet(ef.Destination()).NumShips()
        debug("<< ", ef.Source(), '>>', ef.Destination(),  ' ^', ef.NumShips(), 'vs', dest_ships, " <>", ef.TurnsRemaining())
    
    fleets = pw.Fleets()
    eos = estimatedCharacterOffenceStrength(pw, 2, eplanets, mplanets, efleets, mfleets)
    eds = estimatedCharacterDefenceStrength(eplanets, fleets)
    mos = estimatedCharacterOffenceStrength(pw, 1, mplanets, eplanets, mfleets, efleets)
    mds = estimatedCharacterDefenceStrength(mplanets, fleets)
    
    my_production = pw.MyProduction() 
    enemy_production = pw.EnemyProduction()
    
    enemy_threat = -eos + mds
    my_threat = mos + eds
    
    debug("# My total strength,    >>", mos, ' ||', mds, ' $', my_production, ' %>', my_threat)
    debug("# Enemy total strength, >>", -eos, ' ||', -eds, ' $', enemy_production, ' %>', enemy_threat)
    
def debugTime(begintime):
    global maxtime, maxtimeTurn, gameturn
    endtime = time.clock()
    if maxtime < (endtime - begintime):
        maxtime = (endtime - begintime)
        maxtimeTurn = gameturn
    debug("Clock: ", (endtime - begintime), 's Max:', maxtime, 's @', maxtimeTurn)
        
def DoTurn(pw):
    global gameturn
    
    debugStatus(pw)
    
    debug("REINFORCEMENTS AND DEFENCE #######################");
    reserveOwnPlanetsDefence(pw)
    defendOwnPlanets(pw)
    debug("RECAPTURE-----------------------------------------");
    recapturePlanets(pw)
    debug("ATTACK--------------------------------------------");
    attackEnemy(pw)
    debug("REINFORCEMENTS -----------------------------------");
    reinforceOwn(pw)
    
    gameturn += 1

def mapFleetsToTurns(fleets):
    fleets.sort(lambda f,s: cmp(f.TurnsRemaining(), s.TurnsRemaining()))
    curturn = min([ef.TurnsRemaining() for ef in fleets])
    curturn_fleets = []
    turn_list = [(curturn, curturn_fleets)]
    
    for ef in fleets:
        turn = ef.TurnsRemaining()
        if curturn != turn:
            curturn = turn
            curturn_fleets = []
            turn_list.append((curturn, curturn_fleets))
        curturn_fleets.append(ef)
    
    turn_list.sort(lambda f,s: cmp(f[0], s[0]))
    return turn_list

def mapFleetsToDestinations(fleets):
    fleets.sort(lambda f,s: cmp(f.Destination(), s.Destination()))
    curdp = min([ef.Destination() for ef in fleets])
    
    curdp_fleets = []
    dp_list = [(curdp, curdp_fleets)]
    
    for ef in fleets:
        dp = ef.Destination()
        if curdp != dp:
            curdp = dp
            curdp_fleets = []
            dp_list.append((curdp, curdp_fleets))
        curdp_fleets.append(ef)
    
    dp_list.sort(lambda f,s: cmp(f[0], s[0]))
    return dp_list

def reserveOwnPlanetsDefence(pw):
    dplanets = pw.MyPlanets()
    eplanets = pw.EnemyPlanets()
    fleets = pw.Fleets()
    
    for dp in dplanets:
        incomingFleets = dp.IncomingFleets()
        
        if len(incomingFleets) == 0:
            continue
        
        #for inf in incomingFleets:
        #    debug('         Fleet to: ', inf.Destination(), '<>', inf.TurnsRemaining(), '^', inf.NumShipsDispatch(), 'own:', inf.Owner())
        closestEnemyDistance = dp.ClosestEnemy().DistanceTo(dp) if len(eplanets) > 0 else sys.maxint
        spds = dp.NumShips()
        
        #debug("     ", sp.ID(), "There are incoming fleets:", len(incomingFleets))
        for turn,turn_fleets in mapFleetsToTurns(incomingFleets):
            _spds, _spowner = estimatedPlanetDefenceStrength(dp, fleets, turnlimit=min(turn, closestEnemyDistance)) 
            #debug("     planet:", sp.ID(), "fleets @", turn, ":", len(turn_fleets), 'spds:', _spds, 'owner:', _spowner)
            if _spowner != dp.Owner():
                spds = 0
            elif spds > _spds:
                spds = _spds
        
        debug(">>> RESERVING FOR DEFENCE in", dp.ID(), ":", spds)
        dp.ReserveShips(max(dp.NumShips() - spds, 0))

def defendOwnPlanets(pw):
    """ Manage defence of own planets:  """
    fleets = pw.Fleets()
    mfleets = pw.MyFleets()
    splanets = pw.MyPlanets()
    dplanets = []
    dplanets += pw.MyPlanets()
    eplanets = pw.EnemyPlanets()
    
    mfleets_to_neutrals = filter(lambda mf: pw.GetPlanet(mf.Destination()).Owner() == 0, mfleets)
    dplanets += [pw.GetPlanet(mf.Destination()) for mf in mfleets_to_neutrals]
    
    splanets.sort(lambda f,s: -cmp(f.NumShips(), s.NumShips));
    dplanetid = map(lambda p: p.ID(), dplanets)
    
    efleets = filter(lambda ef: ef.Destination() in dplanetid, pw.EnemyFleets())
    
    planetRatingL = lambda f: planetRatingDefence(f, eplanets, splanets)
    dplanets.sort(lambda f,s: -cmp(planetRatingL(f), planetRatingL(s)))
    
    #for dp in dplanets:
    #    debug("P-RATING:", dp.ID(), "R: %.2f" % planetRatingL(dp), " +:", dp.GrowthRate(), "^", dp.NumShips())
    
    if len(efleets) == 0:
        return
    
    # map fleets to planets:
    dpfleets = mapFleetsToDestinations(efleets)
    
    for dpid, defleets in dpfleets:
        sent = 0
        dp = pw.GetPlanet(dpid)
        turnlimit = dp.ClosestEnemy().DistanceTo(dp) if len(eplanets) > 0 else sys.maxint
        dpds,dpowner = estimatedPlanetDefenceStrength(dp, fleets)
        debug("RESCUE FOR: ||", dp.ID(), 'dpds:', dpds, 'owner:', dpowner)
        
        if dpowner == 1 or len(defleets) == 0:
            continue
        
        rescuePlan = createRescuePlan(dp, fleets, defleets, 0, turnlimit)
        rescuePlanets = findResourcesForRescue(dp, splanets, eplanets, fleets, rescuePlan)
        executeRescuePlan(pw, dp, rescuePlanets, splanets)

def recapturePlanets(pw):
    """ Opportunistic weak enemy recapture """
    fleets = pw.Fleets()
    mfleets = pw.MyFleets()
    splanets = pw.MyPlanets()
    dplanets = pw.NeutralPlanets() + filter(lambda p: not p.IsRescued(), pw.MyPlanets())
    eplanets = pw.EnemyPlanets()
    
    dplanetid = [dp.ID() for dp in dplanets]
    
    efleets = filter(lambda ef: ef.Destination() in dplanetid, pw.EnemyFleets())
    
    splanets.sort(lambda f,s: -cmp(f.NumShips(), s.NumShips));
    
    planetRatingL = lambda f: planetRatingDefence(f, eplanets, splanets)
    dplanets.sort(lambda f,s: -cmp(planetRatingL(f), planetRatingL(s)))
    
    #for dp in dplanets:
    #    debug("P-RATING:", dp.ID(), "R: %.2f" % planetRatingL(dp), " +:", dp.GrowthRate(), "^", dp.NumShips())
    
    if len(efleets) == 0:
        return
    
    # map fleets to planets:
    dpfleets = mapFleetsToDestinations(efleets)
    
    for dpid, defleets in dpfleets:
        dp = pw.GetPlanet(dpid)
        
        turnlimit = dp.ClosestEnemy().DistanceTo(dp) if len(eplanets) > 0 else 0
        dpds,dpowner = estimatedPlanetDefenceStrength(dp, fleets, turnlimit=turnlimit)
        
        debug("Recapture opportunity: >>", dp.ID(), 'dpds:', dpds, 'owner:', dpowner)
        
        if dpowner == 1 or dpowner == 0 or len(defleets) == 0:
            continue
        
        rescuePlan = createRescuePlan(dp, fleets, defleets, 1, turnlimit)
        rescuePlanets = findResourcesForRescue(dp, splanets, eplanets, fleets, rescuePlan)
        executeRescuePlan(pw, dp, rescuePlanets, splanets)

def createRescuePlan(dp, fleets, defleets, turndelta, turnlimit):
    # STEP 1: map enemy fleets to turns in which they will come to the dp
    # map fleets to destination maps, filtering out only those coming to ours
    defleets_turns = mapFleetsToTurns(defleets)
    
    # STEP 2: get amount of needed ships in each turn and concoct a rescue plan
    fanthom_fleets = []
    for turn, tdefleets in defleets_turns:
        dpds_turn,dpowner_turn = estimatedPlanetDefenceStrength(dp, fleets+fanthom_fleets, 
            turnlimit=min(turnlimit, turn))
            
        debug("  @turn:", turn, "^", dpds_turn, 'own:', dpowner_turn)

        if dpowner_turn != 1:
            numships = dpds_turn + turndelta * dp.GrowthRate() + turndelta
            ff = Fleet(dp.Owner(), numships, 1, dp.ID(), turn + turndelta, turn + turndelta)
            debug("     Adding:", numships, '@', turn + turndelta)
            fanthom_fleets.append(ff)
    
    rescuePlan = [(ff.TurnsRemaining(), ff.NumShips()) for ff in fanthom_fleets]
    debug("  Rescue plan:", rescuePlan)
    return rescuePlan

def findResourcesForRescue(dp, splanets, eplanets, fleets, rescuePlan):
    # STEP 3: find resources for the rescue plan
    rescuePlanets = []
    safeLimits = dict()
    
    turnlimit = dp.ClosestEnemy().DistanceTo(dp)  if len(eplanets) > 0 else sys.maxint
        
    splanetsnodp = filter(lambda sp: sp.ID() != dp.ID(), splanets)
    
    for sp in splanetsnodp:
        safeLimits[sp.ID()] = safeDispatchLimit(sp, dp, splanets, eplanets, fleets)
        if sp.DistanceTo(dp) < turnlimit:
            safeLimits[sp.ID()] = max(safeLimits[sp.ID()], sp.NumShipsDispatch())
        
    for turn, nships in rescuePlan:
        nships_left = nships
        curRP = []
        for sp in splanetsnodp:
            if turn < sp.DistanceTo(dp): # too close to destination, can't save
                continue
            
            futureGrowth = sp.GrowthRate() * min(turn - sp.DistanceTo(dp), turnlimit)
            safeLimit = safeLimits[sp.ID()] + futureGrowth
            
            if safeLimit <= 0:
                continue
            
            dispatch = min(nships_left, safeLimit)
            nships_left -= dispatch
            debug('  ', sp.ID(), '>>', dp.ID(), 'dispatch:', dispatch, 'safelimit:', safeLimit, 'left:', nships_left, \
                'need:', nships, 'slPure:', safeLimits[sp.ID()], 'futureGrowth', futureGrowth)
            curRP.append([sp, dispatch])
            if nships_left <= 0:
                break
                
        if nships_left > 0:
            debug("  Initial plan not met @", turn, " Left:", nships_left, 'needed:', nships, 'on turn', turn)
            for i in range(len(curRP)):
                if dp.GrowthRate() - curRP[i][0].GrowthRate() > 1:
                    debug("  Risking the smaller planets to gain bigger:", sp.ID(), '>>', dp.ID(), " ^", sp.NumShipsDispatch())
                    sp = curRP[i][0]
                    oldvalue = curRP[i][1]
                    curRP[i][1] = sp.NumShipsDispatch() 
                    nships_left -= sp.NumShipsDispatch() - oldvalue
        
        if nships_left > 0:
            debug("  ABORTING PLAN FOR", dp.ID(), " @", turn, " Left:", nships_left, 'needed:', nships, 'on turn', turn)
            rescuePlanets = []
            break
        
        rescuePlanets.append((turn, nships, curRP))
        #    debug([(turn, [(sp, sl, sp.DistanceTo(dp)) for sp, sl in data]) for turn, data in rescuePlanets])
        #    rescuePlanets = []
        #    break
        
    return rescuePlanets

def executeRescuePlan(pw, dp, rescuePlanets, mplanets):
    for turn, nships, curRP in rescuePlanets:
        nships_left = nships
        for sp, dispatch in curRP:
            if nships_left < 0:
                break
                
            fs = min(dispatch, sp.NumShipsDispatch())
            nships_left -= fs
            distance = sp.DistanceTo(dp)
            if distance == turn and fs > 0:
                debug(">>>>>>>>> EXECUTING:", sp, '>', dp, 'dispatch:', dispatch, 'of', sp.NumShipsDispatch(), 'sending:', fs)
                pw.IssueOrder(sp.ID(), dp.ID(), fs)
                sp.RemoveShips(fs)
            elif distance < turn and fs > 0:
                proxy = findBestProxy(sp, dp, mplanets)
                if proxy.ID() != dp.ID() and (sp.DistanceTo(proxy) + dp.DistanceTo(proxy)) < turn:
                    pw.IssueOrder(sp.ID(), proxy.ID(), fs)
                    debug("Sending ships to best proxy", sp, 'via', proxy.ID(), '>', dp, " @", distance, 'eta', turn-distance, ' fleet:', fs)
                debug("Reserving", sp, '>', dp, " @", distance, 'eta', turn-distance, ' fleets strength:', fs)
                sp.ReserveShips(fs)
                dp.SetRescued(True)

def reinforceOwn(pw):
    """ find the weakest and most remote of own planets and enslave them to feed the bigger ones """
    mplanets = pw.MyPlanets()
    eplanets = pw.EnemyPlanets()
    fleets = pw.Fleets()
    
    myCapturedSoon = getFleetsCaptureSoon(pw, 1, fleets)
    enemyCapturedSoon = getFleetsCaptureSoon(pw, 2, fleets)
    
    if (len(eplanets) == 0 and len(enemyCapturedSoon) == 0) or len(mplanets) == 0 or len(myCapturedSoon) == 0:
        return

    spearhead = min(mplanets, key=lambda p: p.ClosestEnemy().DistanceTo(p))
    
    frontlinePlanets = set()
    frontlinePlanets.add(spearhead)
    frontlinePlanets |= set(filter(lambda p: p.ClosestEnemy().DistanceTo(p) < p.ClosestFriendly().DistanceTo(p), mplanets))
    
    for mcsp, mturnsleft in myCapturedSoon:
        #debug("   captured soon:", mcsp.ID(), '@', mturnsleft)
        closestEnemy = mcsp.ClosestEnemy()
        for ecsp, eturnsleft in enemyCapturedSoon:
            if ecsp.DistanceTo(mcsp) + (eturnsleft - mturnsleft) < mcsp.DistanceTo(closestEnemy):
                closestEnemy = ecsp
        
        closestFriend = mcsp.ClosestFriendly()
        for mcsp_,mtl_ in myCapturedSoon:
            if mcsp_.ID() == mcsp.ID():
                continue
            if mcsp_.DistanceTo(mcsp) + (mtl_ - mturnsleft) < mcsp.DistanceTo(closestFriend):
                closestFriend = mcsp_
                
        #debug("   captured soon:", mcsp.ID(), '@', mturnsleft, \
        #'closestFriend:', closestFriend.ID(), '<>', closestFriend.DistanceTo(mcsp), \
        #'closestEnemy', closestEnemy.ID(), '<>', closestEnemy.DistanceTo(mcsp))
        
        if closestEnemy.DistanceTo(mcsp) < closestFriend.DistanceTo(mcsp):
            #debug("    captured soon:", mcsp.ID(), '@', mturnsleft, "adding to frontline planets")
            frontlinePlanets.add(mcsp)
        
        elif closestEnemy.DistanceTo(mcsp) < spearhead.ClosestEnemy().DistanceTo(spearhead):
            #debug("    captured soon:", mcsp.ID(), '@', mturnsleft, "adding as spearhead to frontline planets")
            frontlinePlanets.add(mcsp)
            if mcsp != spearhead:
                #debug("     removing", spearhead.ID(), "from frontline:", map(lambda p: p.ID(), frontlinePlanets))
                frontlinePlanets.remove(spearhead)
                spearhead = mcsp
        
    rearPlanets = filter(lambda p: p not in frontlinePlanets, mplanets)
    rearPlanets.sort(cmp, key=lambda p: p.ClosestFriendly().DistanceTo(p))
    
    if len(frontlinePlanets) == 0 or len(rearPlanets) == 0:
        return
    
    for sp in rearPlanets:
        
        dp = min(frontlinePlanets, key=lambda p: p.DistanceTo(sp))
        
        closestEnemyToSP = sp.ClosestEnemy().DistanceTo(sp)
        closestFriendlyToSP = sp.ClosestFriendly().DistanceTo(sp)
        
        proxy = findBestProxy(sp, dp, mplanets)
        dispatch = safeDispatchLimit(sp, proxy, mplanets, eplanets, fleets, haveDebug=True) 
        
        if closestFriendlyToSP >= closestEnemyToSP:
            dispatch -= sp.GrowthRate() * closestFriendlyToSP
        
        if dispatch <= 0:
            debug("     ", sp.ID(), '>>', proxy.ID(), '>>', dp.ID(), "safe dispatch limit is 0")
            continue
        
        debug(">>>> REINFORCEMENTS:", sp.ID(), '>>', proxy.ID(), '>>', dp.ID(), ' ^', dispatch, 'of', sp.NumShipsDispatch())
        pw.IssueOrder(sp.ID(), proxy.ID(), dispatch)
        sp.RemoveShips(dispatch)

 
def findBestProxy(sp, dp, splanets):
    if len(splanets) == 0:
        return dp
    splanetsnodp = filter(lambda p: p.ID() != dp.ID(), splanets)
    proxies = []
    for pp in splanetsnodp:
        if (sp.DistanceTo(pp)**2 + dp.DistanceTo(pp)**2) < sp.DistanceTo(dp)**2:
            #debug("Found proxy for", sp.ID(), ">>", dp.ID(), ":", pp.ID(), "|>", sp.DistanceTo(pp), "<->", pp.DistanceTo(dp), "<| <>", sp.DistanceTo(dp))
            proxies.append(pp)
            
    if len(proxies) > 0:
        #debug("Best proxy for:", sp.ID(), ">>", dp.ID(), ":", pp.ID(), "|>", sp.DistanceTo(pp), "<.>", pp.DistanceTo(dp), "<| <>", sp.DistanceTo(dp))
        return min(proxies, key=lambda p: sp.DistanceTo(p))
    return dp
    
def attackEnemy(pw):
    """ Attack enemy, when possible """

    mplanets = pw.MyPlanets()
    eplanets = sanitizePlanets(pw.EnemyPlanets())
    nmplanets = sanitizePlanets(pw.NotMyPlanets())
    
    mfleets = pw.MyFleets()
    efleets = pw.EnemyFleets()
    fleets = pw.Fleets()
    
    performCarefulOffence(pw, nmplanets, eplanets, mplanets, mfleets, fleets)
    dominate(pw, mplanets, eplanets, fleets)

def safeDispatchLimit(sp, dp, mplanets, eplanets, fleets, haveDebug=False):
    if len(eplanets) == 0:
        return 0
    
    distance = sp.DistanceTo(dp)
    
    closestFriendlyDistanceToSP = sp.ClosestFriendly().DistanceTo(sp) if len(mplanets) > 0 else sys.maxint
    closestEnemyDistanceToSP = sp.ClosestEnemy(exclude=[dp]).DistanceTo(sp) # XXX: this exclude may not work
    
    spIncomingFleets = sp.IncomingFleets()
    spds,spowner = estimatedPlanetDefenceStrength(sp, spIncomingFleets, turnlimit=closestEnemyDistanceToSP)
    
    if spowner != sp.Owner():
        return 0
    
    incomingFleets = sp.IncomingFleets()
    #for inf in incomingFleets:
    #    debug('         Fleet to: ', inf.Destination(), '<>', inf.TurnsRemaining(), '^', inf.NumShipsDispatch(), 'own:', inf.Owner())
    
    if len(incomingFleets) > 0:
        #debug("     ", sp.ID(), "There are incoming fleets:", len(incomingFleets))
        for turn,turn_fleets in mapFleetsToTurns(incomingFleets):
            _spds, _spowner = estimatedPlanetDefenceStrength(sp, fleets, turnlimit=min(turn, closestEnemyDistanceToSP)) 
            #debug("     planet:", sp.ID(), "fleets @", turn, ":", len(turn_fleets), 'spds:', _spds, 'owner:', _spowner)
            if _spowner != sp.Owner():
                spds = 0
            elif spds > _spds:
                spds = _spds
        
        #debug("     Setting min spds for", sp.ID(), "to:", spds)

    if spds <= 0:
        return 0
        
    calcOffencePotentialVsSP = lambda ep: min(estimatePlanetOffensiveThreat(ep, sp, fleets), 0)
    calcDefenceStrength = lambda p: estimatedPlanetDefenceStrength(p, fleets, turnlimit=closestEnemyDistanceToSP)
    
    epmaxop = min(eplanets, key=calcOffencePotentialVsSP)
    epos = calcOffencePotentialVsSP(epmaxop)
    
    eplanetsnodp = filter(lambda ep: ep.ID() != dp.ID(), eplanets)
    mplanetsnodp = filter(lambda mp: mp.ID() != dp.ID(), mplanets)
    
    epgos = planetGroupOffenceStrength(sp, eplanetsnodp, fleets, closestFriendlyDistanceToSP)
    max_eos = min(epos, epgos)
    
    spgds = planetGroupDefenceStrength(sp, mplanetsnodp, fleets, closestEnemyDistanceToSP, haveDebug=haveDebug)
    if dp.Owner() == sp.Owner():
        spgds += spds
        
    max_mds = max(spds, spgds)
    
    if haveDebug:
        debug("     Check safe dispatch limit for", sp.ID(), ">", dp.ID(), "spds:", spds, "spgds:", spgds, \
        "epos:", -epos, "epgos:", -epgos, "Final:", max_mds, max_eos, '=', max_mds + max_eos, " of sp", sp.NumShipsDispatch())
    
    # defensive analysis: compare strength of our planet 
    # to offence potential of the enemy planet
    # we're safe and sound for spds + max_eos > 0
    # we're good to attack the enemy, while spds + epos + dpds > 0
    #debug('Left before attack: ', sp.NumShips(), '? >', max_mds + max_eos, sp, sp.ID())
    limit = min(max_mds + max_eos, sp.NumShipsDispatch())
    
    if max_mds + max_eos > 0:
        return limit
        
    return 0 # restrict dispatch
    
def getFleetsCaptureSoon(pw, fowner, fleets):
    capturedSoon = []

    for f in fleets:
        fdp = pw.GetPlanet(f.Destination())
        #if fdp.Owner() == fowner:
        #    continue
        dpds, dpowner = estimatedPlanetDefenceStrength(fdp, fleets)
        if dpowner == fowner and fdp.Owner() != dpowner:
            capturedSoon.append((fdp, f.TurnsRemaining()))
            
    return capturedSoon
    
def debugPlanetRatings(dplanets_ratings, dplanets):
    #for dp, rating in dplanets_ratings:
    #    debug("P-RATING:", dp.ID(), "R: %.2f" % rating, "<> %.2f" % planetDistanceBlob(dp, dplanets), " +:", \
    #    dp.GrowthRate(), "^", dp.NumShipsDispatch(), "ROI %.2f" % (dp.NumShipsDispatch() / (dp.GrowthRate() + 1e-128)))
    pass


def performCarefulOffence(pw, dplanets, eplanets, mplanets, mfleets, fleets):
    dplanets_ratings = [(dp, planetRating(dp, mplanets, eplanets)) for dp in dplanets]
    dplanets_ratings.sort(lambda f,s: -cmp(f[1], s[1]))
    
    ## Include my soon-to-be-captured destinations into the proxy list
    myCapturedSoon = getFleetsCaptureSoon(pw, 1, fleets)
    enemyCapturedSoon = getFleetsCaptureSoon(pw, 2, fleets)
    
    debugPlanetRatings(dplanets_ratings, dplanets)
    
    if len(eplanets) == 0 or len(dplanets) == 0:
        return
    
    for dp,dprating in dplanets_ratings:
        
        eplanetsnodp = filter(lambda ep: ep.ID() != dp.ID(), eplanets)
        mplanetsnodp = filter(lambda mp: mp.ID() != dp.ID(), mplanets)
        
        closestEnemyDistanceToDP = sys.maxint
        
        if len(eplanetsnodp) > 0:
            closestEnemyDistanceToDP = min([dp.DistanceTo(ep) for ep in eplanetsnodp])
        
        dpds, dpowner = estimatedPlanetDefenceStrength(dp, fleets, turnlimit=closestEnemyDistanceToDP)
        enemiesCloserToDP = filter(lambda ep: ep.DistanceTo(dp) <= dp.ClosestFriendly().DistanceTo(dp), eplanetsnodp)
        
        closestFriendDistanceToDP = dp.ClosestFriendly().DistanceTo(dp) if len(mplanets) > 0 else sys.maxint
        
        dpgds = planetGroupDefenceStrength(dp, eplanetsnodp, fleets, closestFriendDistanceToDP)#, haveDebug=True)
        dpgds -= dpds
        
        if dpgds >= 0:
            dpgds = -dpds
        
        debug( "# DP: >", dp.ID(), "owner now:", dp.Owner(), 'next:', dpowner, \
        " +", dp.GrowthRate(), " ^", dp.NumShipsDispatch(), " R %.2f" % dprating, \
        " dpgds", -dpgds, "dpds", dpds, '@', closestFriendDistanceToDP)
        
        if dpowner == 1: # already successfully attacked by me
            continue 
        
        dispatch_plan = []
        avg_dpdp = 0
        
        for sp in mplanets:
            fproxies = map(lambda p: p[0], filter(lambda item: item[1] < sp.DistanceTo(item[0]), myCapturedSoon))
            attacklimit = safeDispatchLimit(sp, dp, mplanets, eplanets, fleets)
            dpdp = estimatedPlanetDefencePotential(sp, dp, dpowner, -dpgds, fleets)
            proxy = dp
            if sp.DistanceTo(dp) * 2 >= closestEnemyDistanceToDP:
                proxy = findBestProxy(sp, dp, mplanets + fproxies)
            dispatch_plan.append((attacklimit, dpdp, sp, proxy))
        
        dispatch_plan.sort(lambda f,s: cmp(f[1], s[1]))
        
        min_dpdp_source = None
        
        # TODO: See, if the enemy is going to capture a planet close to DP sooner, than DP can be 
        # captured and take it also into account (of course, also the moment of capture and 
        # subsequent strength, too)
        for limit, dpdp, sp, proxy in dispatch_plan:
            debug( "     A:", sp.ID(), ">", dp.ID(), "limit:", limit, "min need:", dpdp + 1)
            if limit < dpdp + 1:
                continue
            
            closestEnemyToSP = sp.ClosestEnemy()
            
            # enemies closer than any of the friendlies must be counted as one cumulative threat
            #calcOffencePotentialVsSP = lambda ep: estimatePlanetOffensiveThreat(ep, sp, fleets)
            
            ff = [Fleet(sp.Owner(), limit, sp.ID(), dp.ID(), sp.DistanceTo(dp), sp.DistanceTo(dp))]
            
            dpds_after,dpowner_after = estimatedPlanetDefenceStrength(dp, fleets+ff, 
                turnlimit=min(sp.DistanceTo(dp), closestEnemyDistanceToDP + 1))
            
            if dpowner_after != 1:
                continue
            
            if dpowner == 2:
                need = dpdp + 1
                if limit < need and dp.GrowthRate() - sp.GrowthRate() > 1:
                    limit = sp.NumShipsDispatch()
                if min_dpdp_source and min_dpdp_source[1] <= need:
                    continue
                debug("         Enemy attack check: limit:", limit, "need(dpdp+1):", need)
                min_dpdp_source = (limit, need, sp, proxy)
                continue
            
            dpgds_after = planetGroupDefenceStrength(dp, mplanetsnodp, fleets + ff, closestEnemyDistanceToDP)
            dpgds_after += dpds_after
            
            maxmdsdp = max(dpgds_after, dpds_after)
            
            debug( "         Sustainability check:", sp.ID(), ">", dp.ID(), "dpds_after:", dpds_after, \
            "dpowner_after:", dpowner_after, "dpgds_after", dpgds_after)
            
            eopVsDP_After = lambda p: estimatePlanetOffensiveThreat(ep, dp, fleets) - \
                (ep.DistanceTo(dp) - sp.DistanceTo(dp)) * ep.GrowthRate()
            
            eposdp_after = 0
            
            if len(eplanetsnodp):
                epdp = min(eplanetsnodp, key=lambda p: min(eopVsDP_After(p), 0))
                eposdp_after = min(eopVsDP_After(epdp), 0)
            
            enemyCapturedBeforeDP = map(lambda p: p[0], filter(lambda ep: sp.DistanceTo(dp) <= ep[1], enemyCapturedSoon))
            epgosdp_after = sum([min(eopVsDP_After(ep), 0) for ep in enemiesCloserToDP + enemyCapturedBeforeDP])
            
            maxeosdp = min(eposdp_after, epgosdp_after)
            
            need = dpdp + 1 - maxmdsdp - maxeosdp if maxmdsdp <= -maxeosdp else dpdp + 1
            
            debug("         >>", dp.ID(), 'maxmdsdp:', maxmdsdp, 'maxeosdp:', -maxeosdp, 'need:', need, 'dpdp:', dpdp)
            debug("         >>", dp.ID(), "sum(", dpdp, 1, -maxmdsdp, -maxeosdp, ")")
            
            # risking or sacrificing smaller planets for bigger planets
            if limit < need and dp.GrowthRate() - sp.GrowthRate() > 1:
                limit = sp.NumShipsDispatch()
            
            # if the previous chosen is already smaller, bypass the current one
            if min_dpdp_source and min_dpdp_source[1] <= need:
                continue
            
            closestFutureEnemyDistanceToDP = min(map(lambda p: p[1] + p[0].DistanceTo(dp), enemyCapturedSoon)) \
                if len(enemyCapturedSoon) > 0 else sys.maxint

            distance = sp.DistanceTo(dp)
            
            if distance < closestEnemyDistanceToDP and distance < closestFutureEnemyDistanceToDP:
                debug('    ALLOWING MINIMAL FORCE of ', dpdp + 1, 'limit:', limit)
                min_dpdp_source = (limit, dpdp + 1, sp, proxy)
                continue
            
            debug('   REQUIRING FULL FORCE of ', need, 'limit:', limit)
            min_dpdp_source = (limit, need, sp, proxy)
            
        if not min_dpdp_source:
            continue
        
        attacklimit, dispatch, sp, proxy = min_dpdp_source
        
        if dispatch > min(attacklimit, sp.NumShipsDispatch()):
            continue
        
        #debug("Found best proxy for ", sp.ID(), '>>', orig_dp.ID(), ":", dp.ID(), "In future proxies:", dp in fproxies, "; proxies:", [str(fpp) for fpp in fproxies])
        
        # compensate for the additional turns it will take to route the attack through the proxy
        compensation = 0
        if dpowner != 0:
            compensation = (sp.DistanceTo(proxy) + proxy.DistanceTo(dp) - sp.DistanceTo(dp)) * dp.GrowthRate()
            if dispatch + compensation > min(attacklimit, sp.NumShipsDispatch()):
                proxy = dp
                compensation = 0
            
        debug(">>>>>>>> ATTACKING:", sp.ID(), ">>", proxy.ID(), ">>", dp.ID(), \
            '<>', sp.DistanceTo(proxy), "+", dp.DistanceTo(proxy), "=", sp.DistanceTo(proxy)+dp.DistanceTo(proxy),\
            "need:", need, "have:", sp.NumShipsDispatch(), '>>', dispatch, 'vs', dp.NumShips())
        pw.IssueOrder(sp.ID(), proxy.ID(), dispatch + compensation)
        sp.RemoveShips(dispatch + compensation)
        #debug('Left after attack:', sp.NumShipsDispatch(), " < ", sp)

def dominate(pw, mplanets, eplanets, fleets):
    if len(eplanets) == 0 or len(mplanets) == 0:
        return
    
    if pw.MyProduction() <= pw.EnemyProduction():
        return
    
    spearhead = min(mplanets, key=lambda p: p.ClosestEnemy().DistanceTo(p))
    target = spearhead.ClosestEnemy()
    distance = spearhead.DistanceTo(target)

    myCapturedSoon = getFleetsCaptureSoon(pw, 1, fleets)
    enemyCapturedSoon = getFleetsCaptureSoon(pw, 2, fleets)
    
    myFutureProduction = sum(map(lambda item: item[0].GrowthRate(), filter(lambda item: item[1] <= distance, myCapturedSoon)))
    enemyFutureProduction = sum(map(lambda item: item[0].GrowthRate(), filter(lambda item: item[1] <= distance, enemyCapturedSoon)))

    if myFutureProduction < enemyFutureProduction:
        return
    
    efleets = pw.EnemyFleets()
    mfleets = pw.MyFleets()
        
    eos = estimatedCharacterOffenceStrength(pw, 2, eplanets, mplanets, efleets, mfleets)
    eds = estimatedCharacterDefenceStrength(eplanets, fleets)
    mos = estimatedCharacterOffenceStrength(pw, 1, mplanets, eplanets, mfleets, efleets)
    mds = estimatedCharacterDefenceStrength(mplanets, fleets)

    enemy_threat = -eos + mds
    my_threat = mos + eds
    
    if enemy_threat >= my_threat:
        return
    
    attacklimit = safeDispatchLimit(spearhead, target, mplanets, eplanets, fleets)
    
    if attacklimit <= 0:
        return
    
    debug("DOMINATION MODE!! ALL YOUR BASE ARE BELONG TO US! ACHTUNG!!!", spearhead.ID(), ">>>", target.ID(), "*", attacklimit)
    pw.IssueOrder(spearhead.ID(), target.ID(), attacklimit)
    spearhead.RemoveShips(attacklimit)
    
def getDispatchFeasibility(sp, dp, closestEPToSP, closestEnemyDistanceToSP, closestEPToDP, closestEnemyDistanceToDP):
    feasibility = 0

    feasibility = sp.GrowthRate() * closestEnemyDistanceToSP - closestEPToDP.GrowthRate() * sp.DistanceTo(dp)
    if dp.Owner() == 1:
        feasibility -= closestEPToDP.GrowthRate() * closestEnemyDistanceToDP
    elif dp.Owner() > 1:
        feasibility += dp.GrowthRate() * closestEnemyDistanceToDP
    
    return feasibility

def planetDistanceBlob(planet, planets):
    if len(planets) <= 0:
        return sys.maxint
    return float(sum(map(lambda p: planet.DistanceTo(p), planets))) / float(len(planets))

def planetDistanceAndGrowthBlob(planet, planets):
    planetsnodp = filter(lambda p: p.ID() != planet.ID(), planets)
    if len(planetsnodp) <= 0:
        return sys.maxint
    
    return sum(map(lambda p: float(p.GrowthRate()) / planet.DistanceTo(p), planetsnodp)) / float(len(planetsnodp))

def planetRating(planet, mplanets, eplanets):
    #edist = 1e-128
    #if len(eplanets) > 0:
    #    edist = float(planetDistanceBlob(planet, eplanets)) + 1e-128
    
    mdist = 1e-128
    if len(mplanets) > 0:
        mdist = float(planetDistanceBlob(planet, mplanets)) + 1e-128
    
    rating = 0    
    if planet.Owner() == 2:
        rating = -mdist + planet.GrowthRate()
    else:
        rating = -mdist - float(planet.NumShips()) / (float(planet.GrowthRate()) + 1e-128)
    
    return rating

def planetRatingDefence(planet, eplanets, mplanets):
    edist = 0.0
    if len(eplanets) > 0:
        edist = float(planetDistanceBlob(planet, eplanets))
    
    mdist = 1e-128
    if len(mplanets) > 0:
        mdist = float(planetDistanceBlob(planet, mplanets)) + 1e-128
    
    rating = (edist / mdist) * planet.GrowthRate()
    return rating
    
def estimatedCharacterDefenceStrength(planets, fleets):
    return sum([-pds if pdowner != 1 else pds for pds,pdowner in
        [estimatedPlanetDefenceStrength(p, fleets) for p in planets]])

def estimatedCharacterOffenceStrength(pw, player, splanets, dplanets, sfleets, dfleets):
    if len(splanets) == 0 or len(dplanets) == 0:
        return 0
    
    planetStrength = sum(
        map(lambda sp: 
            max(map(lambda dp: estimatePlanetOffensiveThreat(sp, dp, dfleets), dplanets)) \
            if player == 1 \
            else min(map(lambda dp: estimatePlanetOffensiveThreat(sp, dp, dfleets), dplanets)), splanets))
    
    return int(planetStrength)

def estimatedPlanetDefenceStrength(planet, fleets, turnlimit = sys.maxint):
    """ Estimate planet defensive strength, i.e. how much it can hold up by itself """
    gr = planet.GrowthRate()
    
    powner = planet.Owner()
    pstrength = planet.NumShips()
    
    lfleets = filter(lambda f: f.Destination() == planet.ID(), fleets)
    lfleets = filter(lambda f: f.TurnsRemaining() <= turnlimit, lfleets)
    
    if (len(lfleets)) == 0:
       #debug("pds for:", planet.ID(), '@', turnlimit, (pstrength, powner))
       return (pstrength, powner)
    
    turn_list = mapFleetsToTurns(lfleets)
    
    curturn = 0
    #debug("pds for:", planet.ID(), '@', turnlimit);
    for turn,turn_fleets in turn_list:
        
        turns_interval = (turn - curturn)
        curturn = turn
        my_force = sum([f.NumShips() if f.Owner() == 1 else 0 for f in turn_fleets])
        e_force = sum([f.NumShips() if f.Owner() > 1 else 0 for f in turn_fleets])
        #debug("   o", planet.ID(), '#', turn, '<>', turns_interval, 'owner:', powner, '>< p', pstrength, 'm', my_force, 'e', e_force, 'gr', turns_interval * gr)
        if powner == 0:
            # neutral planets always have their ships decimated with no growth
            # If two enemies meet on a neutral planet, the two strongest will fight with each other
            sides = [[0, pstrength], 
                [1, my_force], 
                [2, e_force]]

            while sides:
                smallest  = min(sides, key=lambda x: x[1])
                sides_max = []
                for s in sides:
                    if s[0] == smallest[0]:
                        continue
                    s[1] -= smallest[1]
                    sides_max.append(s)
                sides = sides_max
            pstrength = smallest[1]
            powner = smallest[0]
        elif powner == 1:
            pstrength += my_force
            pstrength -= e_force
            pstrength += turns_interval * gr
            if pstrength < 0:
                powner = 2
                pstrength = -pstrength
        elif powner == 2:
            pstrength -= my_force
            pstrength += e_force
            pstrength += turns_interval * gr
            if pstrength < 0:
                powner = 1
                pstrength = -pstrength
    
    #debug("   final:", pstrength, powner);
    return (pstrength, powner)

def planetGroupDefenceStrength(planet, planets, fleets, distLimit, haveDebug=False):
    if len(planets) == 0:
        return 0
        
    pgds = 0
    localGroup = filter(lambda p: p.DistanceTo(planet) <= distLimit, planets)
    if haveDebug:
        debug("        pgds for", planet, "@", distLimit, ":", map(lambda p: p.ID(), localGroup))
    calcDefenceStrength = lambda p: estimatedPlanetDefenceStrength(p, fleets, turnlimit=max(0, distLimit - p.DistanceTo(planet)))
    for p in localGroup:
        pds, powner = calcDefenceStrength(p)
        if haveDebug:
            debug("         + pds for", p.ID(), ": ", pds, "owned:", powner, "<>", p.DistanceTo(planet))
        if powner == 1:
            pgds += pds
        else:
            pgds -= pds
            
    return pgds
    
def planetGroupOffenceStrength(planet, planets, fleets, distLimit):
    calcOffencePotential = lambda ep: estimatePlanetOffensiveThreat(ep, planet, fleets)
    localGroup = filter(lambda p: p.DistanceTo(planet) <= distLimit, planets)
    pgos = sum([min(calcOffencePotential(p), 0) for p in localGroup])
    return pgos
    
def estimatedPlanetDefencePotential(sp, dp, dpowner, dpds, fleets):
    """ Calculate the potential of a planet to defend against any attack. Number represents exactly, 
    how many ships must be sent to the planet to capture it. """
    if dpowner == 0: # neutral planets don't grow
        return dpds
    else:
        distance = sp.DistanceTo(dp)
        growthrate = dp.GrowthRate()
        return dpds + growthrate * distance
    
def estimatePlanetOffensiveThreat(sp, dp, fleets, noGrowth = False, turnlimit=sys.maxint):
    """ Calculate the potential of a source planet (sp) to build a successful 
    'all-out' attack on another, dp. Result number represents exactly how many
    ships will be left after the attack.
    """
    distance = sp.DistanceTo(dp)
    
    if sp.Owner() == 0 or dp.Owner() == sp.Owner():
        return 0
    
    growth = dp.GrowthRate()
    
    if dp.Owner() == 0 or noGrowth:
        growth = 0
    
    pstrength, powner = estimatedPlanetDefenceStrength(sp, sp.IncomingFleets(), turnlimit=min(distance * 2, turnlimit))
    
    if len(sp.IncomingFleets()) > 0:
        lastFleet = max(sp.IncomingFleets(), key=lambda f: f.TurnsRemaining())
        pstrength -= growth * lastFleet.TurnsRemaining()
        
    pstrength -= growth * distance
    
    pstrength = -pstrength if sp.Owner() != 1 else pstrength
    return pstrength

def sanitizePlanets(planets):
    """ Filter out wholly undesirable planets """
    return filter(lambda p: p.GrowthRate() > 0, planets)

def coordinatedAttack(pw, eplanets, mplanets, fleets, est_estrength, est_mstrength):
    """ In coordinated attack, all planets send their safe maximum to every enemy planet 

    to build waves of fleets that effectively overwhelm each planet """
    
    total_sent = 0
    attack_plan = []
    eplanets_strength = [(estimatedPlanetDefenceStrength(ep, fleets), ep) for ep in eplanets]
    #filter(lambda p: p[0] >= 0, [(estimatedPlanetDefenceStrength(ep, fleets), ep) for ep in eplanets])
    eplanets_strength.sort(lambda f,s: -cmp(f[0], s[0]))
    
    for dpdata, ep in eplanets_strength:
        dpds, dpowner = dpdata
        max_ships = 0
        sp_dist = 0
        sp = None
        max_ships = 0
        safelimit = 0
        
        for mp in mplanets:
            safelimit = safeDispatchLimit(mp, ep, mplanets, eplanets, fleets)
            debug("PLAN R: Checking ", mp.ID(), ">>", ep.ID(), "^", ships, "vs dpds", -dpds)    
            if ships <= 0:
                continue
            max_ships += ships
            distance = mp.DistanceTo(ep)
            if distance > sp_dist:
                continue
            sp_dist = distance
            sp = mp
        
        if not sp:
            continue
        
        debug("PLAN R: Appending plan from", sp.ID(), ">>", ep.ID(), "^", max_ships, "vs dpds", -dpds)
        attack_plan.append((ep, sp, max_ships, safelimit, dpds))
    
    for ep, sp, max_ships, safelimit, dpds in attack_plan:
        if max_ships + dpds <= 0:
            debug("PLAN R: Not enough ships for PLAN R to planet >>", ep.ID(), ' total^', max_ships, 'vs dpds', -dpds)
            continue
            
        for mp in mplanets:
            num_ships = safeDispatchLimit(mp, ep, eplanets, fleets)
            # risking or sacrificing smaller planets for bigger ones
            if num_ships <= 0 and ep.GrowthRate() - mp.GrowthRate() > 1:
                num_ships = mp.NumShipsDispatch()
            if num_ships <= 0 or total_sent >= max_ships:
                continue

            pw.IssueOrder(mp.ID(), ep.ID(), num_ships)
            total_sent += num_ships
            mp.RemoveShips(num_ships)
            debug("WING ATTACK PLAN R", mp.ID(), '>>', ep.ID(), 'sent ^', num_ships, 'vs', -dpds, 'total', total_sent)
            
def main():
    map_data = ''
    while(True):
        current_line = raw_input()
        if len(current_line) >= 2 and current_line.startswith("go"):
            begintime = time.clock()
            pw = PlanetWars(map_data)
            try:
                DoTurn(pw)
            except Exception, ex:
                raise
            pw.FinishTurn()
            map_data = ''
            debugTime(begintime)
        else:
            map_data += current_line + '\n'

if __name__ == '__main__':
    try:
        import psyco
        psyco.full()
    except ImportError:
        pass
        
    try:
        main()
    except KeyboardInterrupt:
        print 'ctrl-c, leaving ...'
        
